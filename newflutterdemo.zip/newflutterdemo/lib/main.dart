import 'package:flutter/material.dart';
import 'pages/tabbar.dart';
import 'pages/routes.dart';
import 'package:flutter_amap/flutter_amap.dart';

void main(){
  FlutterAmap.setApiKey("d5ba8dc255e9b41e7d8788fcea7b9f0e");
  runApp(MyApp());
}
// 自定义组件  StatelessWidget  无状态组件,状态不可以变的widget   StatefulWidget  是有状态的组件, 持有状态的可能在widget生命周期改变
class MyApp extends StatelessWidget{
 
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return MaterialApp(
        // 设置右上角的debug标志
        debugShowCheckedModeBanner: false,
         // 可以设置导航栏
        home: Tabbar(),
        initialRoute: '/',
        onGenerateRoute: onGenerateRoute,
        // 设置主题
        theme: ThemeData(
          // 设置主题颜色
          primarySwatch: Colors.orange,
          
        ),
    );     
  }
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Scaffold(
        appBar: AppBar(
          title: Text("地图"),
        ),
        body: MyMapView(),
      ),
    );
  }
}

class MyMapView extends StatelessWidget {
   FlutterAmap amap = new FlutterAmap();

 show(){
     amap.show(
         mapview: new AMapView(
             centerCoordinate: new LatLng(39.9242, 116.3979),
             zoomLevel: 13.0,
             mapType: MapType.night,
             showsUserLocation: true),
         title: new TitleOptions(title: "我的地图"));
          amap.onLocationUpdated.listen((Location location){

            print("Location changed $location") ;
      
          });
   }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: show(),
    );
    
  }
}

