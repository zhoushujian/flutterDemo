import 'package:flutter/material.dart';
import './Home/home.dart';
import './Near/near.dart';
import './Mine/mine.dart';
/**
 *   抽离tabbar组件 -- 有状态
 */
class Tabbar extends StatefulWidget {
  final index;  // 参数-默认为0表示首页
  Tabbar({Key key,this.index=0}) : super(key: key);

  _TabbarState createState() => _TabbarState(this.index);
}

class _TabbarState extends State<Tabbar> {
  int _currentIndex = 0;
  _TabbarState(index){
    this._currentIndex = index;
  }
  List bodyList = [
    MyStateFul02(),
    NearBy(),
    Mine()
  ];
  // List titleList = [
  //   "首页",
  //   "附近",
  //   "我的"
  // ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
            // appBar: AppBar(
            //   title: Text(this.titleList[_currentIndex]),
            //   centerTitle: true,
            // ),
            // body: MyIconContainer01(Icons.search,color: Colors.black),
            body: this.bodyList[_currentIndex],
            // 实现底部tabbar
            bottomNavigationBar: BottomNavigationBar(
              currentIndex: this._currentIndex,  // 初始化在哪个bar
              onTap: (int index){
                setState(() {
                  this._currentIndex = index;
                });
              },
              items: <BottomNavigationBarItem>[
                BottomNavigationBarItem(
                  icon: Icon(Icons.home),
                  title: Text("首页")
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.category),
                  title: Text("附近")
                ),
                BottomNavigationBarItem(
                  icon: Icon(Icons.my_location),
                  title: Text("我的")
                ),
                
              ],
              
            )
        );
  }
}
