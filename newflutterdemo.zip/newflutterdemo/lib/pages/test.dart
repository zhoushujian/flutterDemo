import 'package:flutter/material.dart';
import '../res/listData.dart';

/**
 * 有状态组件 点击按钮实现改变数据01
 */
class MyStateFul02 extends StatefulWidget {
  MyStateFul02({Key key}) : super(key: key);

  _MyStateFul02State createState() => _MyStateFul02State();
}

class _MyStateFul02State extends State<MyStateFul02> {
  List list = new List();
  @override
  Widget build(BuildContext context) {
    return ListView(
      children: <Widget>[
        Column(
          children: this.list.map((value){
            return ListTile(
              title: Text(value),
            );
          }).toList(),
        ),
        RaisedButton(
          onPressed: () {
            setState(() {
               this.list.add("添加一条数据01");
            });
           
          },
          child: Text("按钮"),
          
        )
      ],
    );
  }
}


/**
 * 有状态组件 点击按钮实现改变数据01
 */
class MyStateFul01 extends StatefulWidget {
  MyStateFul01({Key key}) : super(key: key);

  _MyStateFul01State createState() => _MyStateFul01State();
}

class _MyStateFul01State extends State<MyStateFul01> {
  int countNum = 0;
  @override
  Widget build(BuildContext context) {
    return Container(
       child: Column(
         children: <Widget>[
            SizedBox(height: 100,),
            Chip(
              label: Text("${this.countNum}"),
              
            ),
            RaisedButton(
              onPressed: () {
                setState(() {
                  this.countNum++;
                });
              },
              child: Text("这是一个按钮"),
              
            )

         ],
       ),
    );
  }
}



class MyWrapLayout01 extends StatelessWidget{
  @override
  Widget build(BuildContext context) {

    return Container(
      color: Colors.yellow,
      height: 600,
      width: double.infinity, // 这个写法就是表示占满整个屏幕
      child: Wrap(
        spacing: 10,// 间距
        // runSpacing: 10,  // 垂直方向间距
        alignment: WrapAlignment.start,  // 左对齐方式
        // direction: Axis.vertical,  // 垂直方向排列
        children: <Widget>[
          MyRaisedButton("第1集"),
          MyRaisedButton("第10集"),
          MyRaisedButton("第110集"),
          MyRaisedButton("第1101集"),
          MyRaisedButton("第1123集"),
          MyRaisedButton("第1543集"),
          MyRaisedButton("第1435集"),
          MyRaisedButton("第154325集"),
          MyRaisedButton("第15435集"),
          MyRaisedButton("第153245集"),
          MyRaisedButton("第431集"),
        ],
      )
    );
    // TODO: implement build
    
  }
}


/**
 * 按钮组件RaisedButton
 */
class MyRaisedButton extends StatelessWidget{
  final String text;
  const MyRaisedButton(this.text,{Key key});
  // const MyRaisedButton(this.text,{Key key});
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return RaisedButton(
      child: Text(this.text), 
      onPressed: () {
        print(this.text);
      },
      textColor: Theme.of(context).accentColor
    );
  }
}


/**
 * 卡片布局 -- Card -- 用本地数据模拟网络数据,加载有图文的卡片
 */

class  MyCard03 extends StatelessWidget{
    @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return ListView(
      children: listData.map((value){
        return Card(
          margin: EdgeInsets.all(10),
          child: Column(
            children: <Widget>[
              AspectRatio(
                aspectRatio: 20/9,
                child: Image.network(value["imageUrl"],fit: BoxFit.cover,),
              ),
              ListTile(
                title: Text(value["title"]),
                subtitle: Text(value["author"]),
              )
            ],

          ),
        ); 
      }).toList()
    );
  }
}


/**
 * 卡片布局 -- Card -- 具有图文的卡片
 */

class  MyCard02 extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return ListView(
      children: <Widget>[
        Card(
          margin: EdgeInsets.all(10),
          child: Column(
            children: <Widget>[
              AspectRatio(
              // 纵横比例
                aspectRatio: 20/9,
                child: Image.network("https://www.itying.com/images/flutter/2.png",fit: BoxFit.cover,),
              ),
              ListTile(
                // CircleAvatar这个控件专门设置头像的
                leading: CircleAvatar(
                  backgroundImage: NetworkImage("https://www.itying.com/images/flutter/1.png"),
                ),
                title: Text("姓名:xxxxxxxx"),
                subtitle: Text("电话:xxxxxx"),
              )
            ],
          ),
        ),
         Card(
          margin: EdgeInsets.all(10),
          child: Column(
            children: <Widget>[
              AspectRatio(
                aspectRatio: 20/9,
                child: Image.network("https://www.itying.com/images/flutter/2.png",fit: BoxFit.cover,),
              ),
              ListTile(
                // ClipOval实现圆图片
                leading: ClipOval(
                  
                  child: Image.network("https://www.itying.com/images/flutter/3.png",height: 40,width: 40,fit: BoxFit.cover,),
                  
                ),
                title: Text("姓名:xxxxx"),
                subtitle: Text("电话:xxxxx"),

              )
            ],
          ),
        )
        
      ],
    );
  }
}


/**
 * 卡片布局 -- Card
 */

class  MyCard01 extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return ListView(
      children: <Widget>[
        Card(
          margin: EdgeInsets.all(10),
          child: Column(
            children: <Widget>[
              ListTile(
                title: Text(
                  "张三",
                  style: TextStyle(fontSize: 28),
                  ),
                  subtitle: Text("高级工程师傅"),
              ),
              ListTile(
                title: Text("电话:XXXXXX"),
              ),
              ListTile(
                title: Text("地址:XXXXXX"),
              ),
              
            ],
          ),
        ),
         Card(
          margin: EdgeInsets.all(10),
          child: Column(
            children: <Widget>[
              ListTile(
                title: Text(
                  "张三",
                  style: TextStyle(fontSize: 28),
                  ),
                  subtitle: Text("高级工程师傅"),
              ),
              ListTile(
                title: Text("电话:XXXXXX"),
              ),
              ListTile(
                title: Text("地址:XXXXXX"),
              ),
              
            ],
          ),
        )
        
      ],
    );
  }
  
}


/**
 * 
 * AspectRatio组件
 */
class  MyAspectRatio extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return AspectRatio(
      // aspectRatio 表示宽高比,  这里宽是占满整屏幕的
      aspectRatio: 3.0/1.0,
      child: Container(
        color: Colors.red,
      ),
      
    );
  }
}

/**
 * 
 * Stack组件--结合Positioned给多个子控件布局
 * 
 */
class  MyStackLayout03 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Center(
      child: Container(
        height: 400,
        width: 300,
        color: Colors.yellow,
        child: Stack(
        // alignment: Alignment.center,
        // Alignment这里面的参数,x,y是-1到1之间变化,就可以达到定位的效果
        alignment: Alignment(-1,1),
        children: <Widget>[
          Positioned(
            left: 0,
            top: 0,
            child: Icon(Icons.home,size: 40,color: Colors.blue,),
          ),
           Positioned(
            right: 0,
            top: 0,
            child: Icon(Icons.select_all,size: 40,color: Colors.green,),
          ),
           Positioned(
            bottom: 0,
            child: Icon(Icons.satellite,size: 40,color: Colors.red,),
          ),
           Positioned(
            bottom: 0,
            right: 0,
            child: Icon(Icons.save,size: 40,color: Colors.pink,),
          ),

        ],
      ),
      ),
    );
  } 
}


/**
 * 
 * Stack组件--结合Align给多个子控件布局
 * 
 */
class  MyStackLayout02 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Center(
      child: Container(
        height: 400,
        width: 300,
        color: Colors.yellow,
        child: Stack(
        // alignment: Alignment.center,
        // Alignment这里面的参数,x,y是-1到1之间变化,就可以达到定位的效果
        alignment: Alignment(-1,1),
        children: <Widget>[
          Align(
            alignment: Alignment(0, 0),
            child: Icon(Icons.home,size: 40,color: Colors.blue,),
          ),
           Align(
            alignment: Alignment(0, 1),
            child: Icon(Icons.select_all,size: 40,color: Colors.green,),
          ),
           Align(
            alignment: Alignment(1, 0),
            child: Icon(Icons.satellite,size: 40,color: Colors.red,),
          ),
           Align(
            alignment: Alignment(1, 1),
            child: Icon(Icons.save,size: 40,color: Colors.pink,),
          ),

        ],
      ),
      ),
    );
  } 
}



/**
 * 
 * Stack组件,  自由定位子控件,相当于前端的悬浮
 * 
 */
class  MyStackLayout01 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Center(
      child: Stack(
        // alignment: Alignment.center,
        // Alignment这里面的参数,x,y是-1到1之间变化,就可以达到定位的效果
        alignment: Alignment(-1,1),
        children: <Widget>[
          Container(
            height: 400,
            width: 300,
            color: Colors.red,

          ),
          Text("我是一个文本"),
          Text("我是一个文本22"),
          Text("我是一个文本454"),
          Text("我是一个文本54题4"),

        ],
      ),
    );
  }
  
}



/**
 * 
 * Layout布局的demo
 */
class  LayoutDemo extends StatelessWidget {
    @override
  Widget build(BuildContext context) {

    // TODO: implement build
    return Column(
      children: <Widget>[
        Row(
          
          children: <Widget>[
            Expanded(
              child: Container(
                height: 180,
                color: Colors.black,
                child: Text('你好flutter'),
              ),
            )
          ],
        ),
        SizedBox(height: 10,),
        Row(         
          children: <Widget>[
            Expanded(
              flex: 2,
              child: Container(
                height: 180,
                child: Image.network("https://www.itying.com/images/flutter/2.png",fit: BoxFit.cover,),
              ),
            ),
            SizedBox(width: 10,),
            Expanded(
              flex: 1,
              child: Container(
                height: 180,
                  child: ListView(
                    children: <Widget>[
                        Container(
                          height: 90,
                          child: Image.network("https://www.itying.com/images/flutter/3.png",fit: BoxFit.cover,),
                        ),
                         SizedBox(height: 10,),
                        Container(
                          height: 90,
                          child:Image.network("https://www.itying.com/images/flutter/1.png",fit: BoxFit.cover,),
                        ),
                     
                     
                     
                    ],
                  )
      
              ),
            )
          ],
        )
      ],
    );
  }
}


/** 
 * 
 * Expanded 组件,  可以做到,让某个子组件占宽的多少份,另外一个子组件占宽度的多少份
 * 
*/

class  MyLayout03 extends StatelessWidget {
    @override
  Widget build(BuildContext context) {

    // TODO: implement build
    return Row(
      children: <Widget>[
        Expanded(
          child: MyIconContainer01(Icons.home,color: Colors.blue,),
          flex: 1,  // 这个参数表示占几份
        ),
        SizedBox(width: 40,),
        Expanded(
          child: MyIconContainer01(Icons.search,color: Colors.pink,),
          flex: 2,  // 这个参数表示占几份
        ),
      ],
    );
  }
}


/** 
 * 
 * 自定义组件的垂直布局
 * 
*/

class  MyLayout02 extends StatelessWidget {
    @override
  Widget build(BuildContext context) {

    // TODO: implement build
    return Container(
      color: Colors.pink,
      height: 600,
      width: 400,
      child: Column(
        // 子控件所在父控件的布局方式
        crossAxisAlignment: CrossAxisAlignment.center,
        // 子控件的布局方式,start: 靠左,end:靠右,spaceEvenly: 均匀分布
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
          MyIconContainer01(Icons.home,color: Colors.blue,),
          MyIconContainer01(Icons.search,color: Colors.red,),
          MyIconContainer01(Icons.send,color:Colors.yellow)
        ],
      ),
    );
  }
}


/** 
 * 
 * 自定义组件的水平布局
 * 
*/

class  MyLayout01 extends StatelessWidget {
    @override
  Widget build(BuildContext context) {

    // TODO: implement build
    return Container(
      color: Color.fromRGBO(233, 233, 233, 1.0),
      height: 600,
      width: 400,
      child: Row(
        // 子控件所在父控件的布局方式
        crossAxisAlignment: CrossAxisAlignment.start,
        // 子控件的布局方式,start: 靠左,end:靠右,spaceEvenly: 均匀分布
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
          MyIconContainer01(Icons.home,color: Colors.blue,),
          MyIconContainer01(Icons.search,color: Colors.pink,),
          MyIconContainer01(Icons.send,color:Colors.yellow)
        ],
      ),
    );
  }
}
/** 
 * mainAxisAlignment: MainAxisAlignment.spaceEvenly,
     
 * 
 * */ 

/** 
 * 
 * 自定义组件
 * 
*/

class  MyIconContainer01 extends StatelessWidget {
  double size = 32.0;
  Color color = Colors.red;
  IconData icon;
  // 构造函数
  MyIconContainer01(this.icon,{this.color,this.size});

    @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      height: 100,
      width: 100,
      color: this.color,
      child: Center(
        child: Icon(this.icon,size: this.size, color: Colors.white,),
      ),
    );
  }
}


// GirdView.count学习 添加 Padding组件
class MyGrideView05 extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return GridView.count(
      padding: EdgeInsets.fromLTRB(0, 0, 10, 0),
      crossAxisCount: 2,
      childAspectRatio:1.7,
        children: <Widget>[
          Padding(
            padding: EdgeInsets.fromLTRB(10, 10, 0, 0),
            child: Image.network("https://www.itying.com/images/flutter/1.png",fit: BoxFit.cover,),
          ),
           Padding(
            padding: EdgeInsets.fromLTRB(10, 10, 0, 0),
            child: Image.network("https://www.itying.com/images/flutter/1.png",fit: BoxFit.cover),
          ),
           Padding(
            padding: EdgeInsets.fromLTRB(10, 10, 0, 0),
            child: Image.network("https://www.itying.com/images/flutter/2.png",fit: BoxFit.cover),
          ),
           Padding(
            padding: EdgeInsets.fromLTRB(10, 10, 0, 0),
            child: Image.network("https://www.itying.com/images/flutter/3.png",fit: BoxFit.cover),
          ),
           Padding(
            padding: EdgeInsets.fromLTRB(10, 10, 0, 0),
            child: Image.network("https://www.itying.com/images/flutter/4.png",fit: BoxFit.cover),
          ),
           Padding(
            padding: EdgeInsets.fromLTRB(10, 10, 0, 0),
            child: Image.network("https://www.itying.com/images/flutter/5.png",fit: BoxFit.cover),
          ),
           Padding(
            padding: EdgeInsets.fromLTRB(10, 10, 0, 0),
            child: Image.network("https://www.itying.com/images/flutter/6.png",fit: BoxFit.cover),
          ),
          
        ],
    );
  }
}

// GirdView.builder学习  自定义View -- 加载本地数据
class MyGrideView04 extends StatelessWidget{
  
  Widget getListData(context, index){
    return Container(
      child: Column(
        children: <Widget>[
          Image.network(listData[index]['imageUrl']),
          SizedBox(height: 12),
          Text(
            listData[index]["title"],
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 16
            ),
          ),
        ],
      ),
      decoration: BoxDecoration(
        border: Border.all(
          color: Color.fromRGBO(233, 233, 233, 0.9),
          width: 1,
        )
      ),
    );
  }
  
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return GridView.builder(
      itemCount: listData.length,
      itemBuilder: this.getListData, 
      // 以下是配置间距等参数
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        // 列数R
        crossAxisCount: 2,
        mainAxisSpacing: 20, // 上下间距
        crossAxisSpacing: 20,  // 左右间距
        // childAspectRatio: 0.7,  // 设置宽高比
        // 这里没法设置padding,所以可以在外面再加container
      ),
       
    );
  }
}

// GirdView -- count学习  自定义View -- 加载本地数据
class MyGrideView03 extends StatelessWidget{
  List<Widget> _getListData(){
   var tempList = listData.map((value){
      return Container(
        child: Column(
          children: <Widget>[
            Image.network(value['imageUrl']),
            SizedBox(height: 12), //  这是设置图片与下面的Text之间的间距
            Text(
              value['title'],
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16
              ),
            ),
          ],
        ),
        // 设置边框
        decoration: BoxDecoration(
          border: Border.all(
            color: Color.fromRGBO(233, 233, 233, 0.9),
            width: 1
          ),
          boxShadow: <BoxShadow>[
            BoxShadow(color: Color.fromRGBO(233, 233, 233, 0.9))
          ]
        ),
      );
   });
   return tempList.toList();
  }
  
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return GridView.count(
      // 表示一行显示多少个
       crossAxisCount: 2,
       // 左右间距
       crossAxisSpacing: 20,
       // 上下间距
       mainAxisSpacing: 20,
       // 距离屏幕边框间距
       padding: EdgeInsets.all(10),
       // 无法直接设置 单元格的高度,需要设置宽高比例-如下代码
      //  childAspectRatio: 0.7,
       children: this._getListData()
    );
  }
}

// GirdView -- count学习  自定义View
class MyGrideView02 extends StatelessWidget{

  List<Widget> _getListData(){
    List<Widget> list = new List();
    for(var i = 0; i < 20; i++){
      list.add(Container(
        alignment: Alignment.center,
        child: Text(
          '这是第$i条数据',
          style: TextStyle(
            color:Colors.pink,
            fontSize: 16
            ),
        ),
         color:Colors.blue,
      ));
    }
    return list;
  }
  

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return GridView.count(
      // 表示一行显示多少个
       crossAxisCount: 3,
       // 左右间距
       crossAxisSpacing: 20,
       // 上下间距
       mainAxisSpacing: 20,
       // 距离屏幕边框间距
       padding: EdgeInsets.all(10),
       // 无法直接设置 单元格的高度,需要设置宽高比例-如下代码
       childAspectRatio: 0.7,
       children: this._getListData()
    );
  }
}

// GirdView -- count学习  相当于UICollectionView
class MyGrideView01 extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return GridView.count(
      // 表示一行显示多少个
       crossAxisCount: 3,
       children: <Widget>[
         Text("这是一个文本"),
         Text("这是一个文本"),
         Text("这是一个文本"),
         Text("这是一个文本"),
         Text("这是一个文本"),
         Text("这是一个文本"),
         Text("这是一个文本"),
         Text("这是一个文本"),
         Text("这是一个文本"),
         Text("这是一个文本"),
         Text("这是一个文本"),
       ],
    );
  }
}



// List.Builder 导入本地数据ListData的第二种写法
class MyListView8 extends StatelessWidget{
  Widget getData(content,index){
    return ListTile(
      leading: Image.network(listData[index]["imageUrl"]),
      title: Text(listData[index]["title"]),
      subtitle: Text(listData[index]["author"]),
    );
  }
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return ListView.builder(
      itemCount: listData.length,
      itemBuilder: this.getData
    );
  }
}

// List.Builder 导入本地数据ListData的第一种写法
class MyListView7 extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return ListView.builder(
      itemCount: listData.length,
      itemBuilder: (context,index){
        return ListTile(
          title: Text(listData[index]["title"]),
        );
      },
    );
  }
}


// List.Builder
class MyListView06 extends StatelessWidget{
  List list = new List();
  // 构造函数
  MyListView06(){
    for(var i = 0; i < 20; i++){
      this.list.add('这是第$i条数据');
    }
  }
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return ListView.builder(
      itemCount: this.list.length,
      itemBuilder: (context,index){
        return ListTile(
          title: Text(this.list[index]),
        );
      },
    );
  }
}


// 获取本地数据展示
class MyListView05 extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return ListView(
       children: this._getData()
    );
  }
 List<Widget> _getData(){
    var tempList = listData.map((value){
        return ListTile(
          leading: Image.network(value["imageUrl"]),
          title: Text(value["title"]),
          subtitle: Text(value["author"]),
        );
    });
    return tempList.toList();
  }
}

// 自定义的列表
class MyListView04 extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return ListView(
       children: this._getData(),
    );
  }

   List<Widget> _getData(){
    List<Widget> list = new List();
    for(var i = 0; i<20; i++){
      list.add(ListTile(
        title: Text("我是$i列表"),
      ));
    }
    return list;
  }
}


// 水平列表
class MyListView03 extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
     return Container(
          height: 180,
          child: ListView(
            // 变成水平列表
          scrollDirection: Axis.horizontal,
            children: <Widget>[
              Container(
                width: 180,     
                color: Colors.red,
              ),
              Container(
                width: 180,       
                color: Colors.orange,
                child: ListView(
                  children: <Widget>[
                    Image.network("https://c-ssl.duitang.com/uploads/item/201807/14/20180714145926_5CxUe.thumb.700_0.jpeg"),
                    Text("我是一个文本")
                  ],
                ),
              ),
              Container(
                width: 180,
                color: Colors.blue,
              ),
              Container(
                width: 180,
                color: Colors.pink,
              )
            ]
              
        ),
    );
   
  }
}

// 图片列表
class MyListView02 extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return ListView(
      children: <Widget>[
        Image.network("https://c-ssl.duitang.com/uploads/item/201807/14/20180714145926_5CxUe.thumb.700_0.jpeg"),
        Container(
          child: Text(
            "我就是一个标题",
            textAlign: TextAlign.center, 
            style: TextStyle(
              fontSize: 28, 
            ),
            ),
          height: 80,
          padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
        ),
        Image.network("https://c-ssl.duitang.com/uploads/item/201807/14/20180714145926_5CxUe.thumb.700_0.jpeg"),
        Image.network("https://c-ssl.duitang.com/uploads/item/201807/14/20180714145926_5CxUe.thumb.700_0.jpeg"),
        Image.network("https://c-ssl.duitang.com/uploads/item/201807/14/20180714145926_5CxUe.thumb.700_0.jpeg"),
        Image.network("https://c-ssl.duitang.com/uploads/item/201807/14/20180714145926_5CxUe.thumb.700_0.jpeg"),

      ],
    );
  }
}


// ListView组件
class MyListView01 extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return ListView(
      padding: EdgeInsets.all(15),
      children: <Widget>[
        ListTile(
          leading: Icon(Icons.settings),
          title: Text(
            "华北大发展",
            style: TextStyle(
               fontSize: 16,
               color: Colors.red
            ),
            ),
          subtitle: Text("你是我的情人,像玫瑰花一样的女人,你是我的情人,像玫瑰花一样的女人,r你是我的情人,像玫瑰花一样的女人,你是我的情人,像玫瑰花一样的女人"),
        ),
        ListTile(
          // 前面的图
          leading: Icon(
            Icons.home,
            color: Colors.blue,
            size: 30,
            ),
          title: Text("华北大发展"),
          subtitle: Text("你是我的情人,像玫瑰花一样的女人"),
        ),
         ListTile(
          leading: Image.network("https://c-ssl.duitang.com/uploads/item/201807/14/20180714145926_5CxUe.thumb.700_0.jpeg"),
          title: Text("华北大发展"),
          subtitle: Text("你是我的情人,像玫瑰花一样的女人"),
          trailing: Icon(Icons.pages),
        ),
      ],
    );
  }
}


// 图片组件  本地图片 远程图片
class MyImage extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        child: Image.network(
          "https://c-ssl.duitang.com/uploads/item/201807/14/20180714145926_5CxUe.thumb.700_0.jpeg",
          //  alignment: Alignment.bottomRight,
           // 渲染图片的颜色--以下两句代码,一起使用
          //  color: Colors.blue,
          //  colorBlendMode: BlendMode.screen,
           fit: BoxFit.cover, // 图片适应模式-用的最多,不会变形
          //  repeat: ImageRepeat.repeat, //图片平铺重复,一张图片没有满,就会有多张图片 
          
          ),
        width: 300,
        height: 300,
        decoration: BoxDecoration(
            color: Colors.yellow,
        ),
      ),
    );
  }
}

// 实现圆形图片-第一种方法
class RoundImage01 extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        width: 300,
        height: 300,
        decoration: BoxDecoration(
            color: Colors.yellow,
            borderRadius: BorderRadius.circular(150),
            image: DecorationImage(
              image: NetworkImage("https://c-ssl.duitang.com/uploads/item/201807/14/20180714145926_5CxUe.thumb.700_0.jpeg"),
              fit: BoxFit.cover
            ),    
        ),
      ),
    );
  }
}

// 实现圆形图片
class RoundImage02 extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
         child: ClipOval(
           child: Image.network(
             'https://c-ssl.duitang.com/uploads/item/201807/14/20180714145926_5CxUe.thumb.700_0.jpeg',
             height: 100,
             width: 100,
             fit: BoxFit.cover,
             )
         ),
      ),
    );
  }
}

// 显示本地图片
class RoundImage03 extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
         child: Image.asset("images/pic_sale_mallparking_month.png",
        fit:BoxFit.cover
        ),
        width: 300.0,
        height: 300.0,
        decoration: BoxDecoration(
        color: Colors.yellow ),
      ),
    );
  }
}


// Container组件  相当于前端的div或者  OC的UIView
class MyContainer extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
         child: Text(
           '小猫科技小猫科技小猫科技小猫科技小猫科技小猫科技小猫科技小猫科技小猫科技',
           textAlign: TextAlign.left, 
            overflow: TextOverflow.ellipsis,   // 超出部分如何处理,显示...
            maxLines: 3,
            textScaleFactor: 2,
            style: TextStyle(
              fontSize: 16.0,
              color: Colors.red
            ),
         ),
         height: 300,
         width: 300,
         decoration: BoxDecoration(
           color: Colors.yellow,
           border: Border.all(
             color:Colors.blueGrey,
             width: 2.0
           ),
            borderRadius: BorderRadius.all(
              Radius.circular(30),
            ),

         ),
        //  padding: EdgeInsets.all(10),
        padding: EdgeInsets.fromLTRB(10, 15, 10, 10),
        // 位移
        // transform: Matrix4.translationValues(100, 0, 0),
        // transform: Matrix4.rotationZ(0.3),// 沿着z轴旋转
        // 文字的显示位置
        alignment: Alignment.topRight,
        
      ),
    );
  }
}

class HomeContent extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Center(
        child: Text(
          '你好Flutter 111',
          textDirection: TextDirection.ltr,
          style:TextStyle(
            color: Colors.red,
            // color: Color.fromRGBO(233, 233, 233, 0.5),
            fontSize: 34,
          )
        ),
    );
  }
}

// 数组
/**
 * /*
List里面常用的属性和方法：

    常用属性：
        length          长度
        reversed        翻转
        isEmpty         是否为空
        isNotEmpty      是否不为空
    常用方法：  
        add         增加
        addAll      拼接数组
        indexOf     查找  传入具体值
        remove      删除  传入具体值
        removeAt    删除  传入索引值
        fillRange   修改   
        insert(index,value);            指定位置插入    
        insertAll(index,list)           指定位置插入List
        toList()    其他类型转换成List  
        join()      List转换成字符串
        split()     字符串转化成List
        forEach   
        map
        where
        any
        every

*/


void main(){

  // List myList=['香蕉','苹果','西瓜'];
  // print(myList[1]);


  // var list=new List();
  // list.add('111');
  // list.add('222');
  // print(list);


//List里面的属性：
    // List myList=['香蕉','苹果','西瓜'];
    // print(myList.length);
    // print(myList.isEmpty);
    // print(myList.isNotEmpty);
    // print(myList.reversed);  //对列表倒序排序
    // var newMyList=myList.reversed.toList();
    // print(newMyList);

//List里面的方法：


    // List myList=['香蕉','苹果','西瓜'];
    //myList.add('桃子');   //增加数据  增加一个

    // myList.addAll(['桃子','葡萄']);  //拼接数组

    // print(myList);

    //print(myList.indexOf('苹x果'));    //indexOf查找数据 查找不到返回-1  查找到返回索引值


    // myList.remove('西瓜');

    // myList.removeAt(1);

    // print(myList);
  



    // List myList=['香蕉','苹果','西瓜'];

    // myList.fillRange(1, 2,'aaa');  //修改

    //  myList.fillRange(1, 3,'aaa');  


    // myList.insert(1,'aaa');      //插入  一个

    // myList.insertAll(1, ['aaa','bbb']);  //插入 多个

    // print(myList);






    // List myList=['香蕉','苹果','西瓜'];

    // var str=myList.join('-');   //list转换成字符串

    // print(str);

    // print(str is String);  //true


    var str='香蕉-苹果-西瓜';

    var list=str.split('-');

    print(list);

    print(list is List);

  


  


}
 * 
 * 
 * 
 * 
*/