import 'package:flutter/material.dart';


class NearBy extends StatefulWidget {
  NearBy({Key key}) : super(key: key);
  

  _NearByState createState() => _NearByState();
}

class _NearByState extends State<NearBy> {
  //  Future<bool> _onWillPop()=>new Future.value(false);
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
       drawer: Drawer(
          child: Column(
            children: <Widget>[
              Row(
                children: <Widget>[
                  Expanded(
                    child: UserAccountsDrawerHeader(
                      accountName: Text("周述坚"),
                      accountEmail: Text("394002732@qq.com"),
                      currentAccountPicture: CircleAvatar(
                        backgroundImage: NetworkImage("https://www.itying.com/images/flutter/2.png"),
                      ),
                      decoration:BoxDecoration(
                        color: Colors.yellow,
                        image: DecorationImage(
                          image: NetworkImage("https://www.itying.com/images/flutter/3.png"),
                          fit:BoxFit.cover,
                        )                       
                      )
                    ),
                    
                  )
                ],
              ),
              ListTile(
                leading: CircleAvatar(
                  child: Icon(Icons.home)
                ),
                title: Text("我的空间"),
              ),
                Divider(),
               ListTile(
                leading: CircleAvatar(
                  child: Icon(Icons.people)
                ),
                title: Text("用户中心"),
              ),
              Divider(),
              ListTile(
                leading: CircleAvatar(
                  child: Icon(Icons.settings)
                ),
                title: Text("设置中心"),
              ),
                Divider(),
            ],
          ),
       ),
      //  endDrawer: Drawer(
      //    child: Text("右侧边栏"),
      //  ),
       appBar: AppBar(
         title: Text("附近"),
        //  leading: IconButton(
           
        //    onPressed: () => Scaffold.of(context).openDrawer(), 
        //    icon: Icon(Icons.menu),
        //    tooltip: "Search",
        //  ),
        leading: Builder(
            builder: (context) => IconButton(
                  icon: new Icon(Icons.menu),
                  onPressed: () => Scaffold.of(context).openDrawer(),
                ),
        ),

         actions: <Widget>[
           IconButton(
             onPressed: () {
                 print("Search pressed");
              }, 
             icon: Icon(Icons.search),
              tooltip: "Search",
           ),
           IconButton(
              icon: Icon(Icons.more_horiz), tooltip: "more_horiz", onPressed: (){
                print('more_h oriz Pressed'); }
            )
         ],
       ),
       
       body: LayoutDemo(),
    );
  }
}

class LayoutDemo extends StatelessWidget {
  const LayoutDemo({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // return MyIconContainer01(Icons.search,color: Colors.black);
    return MyWrapLayout01();
  }
}

/** 
 * 
 * 自定义按钮组件,传参到类中,控制控件颜色等
 *  
 * 
*/

class  MyIconContainer01 extends StatelessWidget {
  double size = 32.0 ;
  Color color = Colors.red;
  IconData icon;
  // 构造函数
  MyIconContainer01(this.icon,{this.color,this.size});

    @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      height: 100,
      width: 100,
      color: this.color,
      child: Center(
        child: Icon(this.icon,size: this.size, color: Colors.white,),
      ),
    );
  }
}

/** 
 * 
 * 自定义组件的水平布局-- Row
 * 
*/

class  MyLayout01 extends StatelessWidget {
    @override
  Widget build(BuildContext context) {

    // TODO: implement build
    return Container(
      color: Color.fromRGBO(233, 233, 233, 1.0),
      height: 600,
      width: 400,
      child: Row(
        // 子控件所在父控件的布局方式
        crossAxisAlignment: CrossAxisAlignment.start,
        // 子控件的布局方式,start: 靠左,end:靠右,spaceEvenly: 均匀分布
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
          MyIconContainer01(Icons.home,color: Colors.blue,),
          MyIconContainer01(Icons.search,color: Colors.pink,),
          MyIconContainer01(Icons.send,color:Colors.yellow)
        ],
      ),
    );
  }
}

/**
 * 
 * Layout布局的demo
 */
class  LayoutDemo02 extends StatelessWidget {
    @override
  Widget build(BuildContext context) {

    // TODO: implement build
    return Column(
      children: <Widget>[
        Row(
          children: <Widget>[
            Expanded(
              child: Container(
                height: 180,
                color: Colors.green,
                child: Text('你好flutter'),
              ),
            )
          ],
        ),
        SizedBox(height: 10,),
        Row(         
          children: <Widget>[
            Expanded(
              flex: 2,
              child: Container(
                height: 180,
                child: Image.network("https://www.itying.com/images/flutter/2.png",fit: BoxFit.cover,),
              ),
            ),
            SizedBox(width: 10,),
            Expanded(
              flex: 1,
              child: Container(
                height: 180,
                  child: ListView(
                    children: <Widget>[
                        Container(
                          height: 90,
                          child: Image.network("https://www.itying.com/images/flutter/3.png",fit: BoxFit.cover,),
                        ),
                         SizedBox(height: 10,),
                        Container(
                          height: 90,
                          child:Image.network("https://www.itying.com/images/flutter/1.png",fit: BoxFit.cover,),
                        ),
                     
                     
                     
                    ],
                  )
      
              ),
            )
          ],
        )
      ],
    );
  }
}

/**
 * 
 * Stack组件,  自由定位子控件,相当于前端的悬浮
 * 
 */
class  MyStackLayout01 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Center(
      child: Stack(
        // alignment: Alignment.center,
        // Alignment这里面的参数,x,y是-1到1之间变化,就可以达到定位的效果
        alignment: Alignment(-1,1),
        children: <Widget>[
          Container(
            height: 400,
            width: 300,
            color: Colors.red,

          ),
          Text("我是一个文本"),
          Text("我是一个文本22"),
          Text("我是一个文本454"),
          Text("我是一个文本54题4"),

        ],
      ),
    );
  }
  
}

/**
 * 
 * Stack组件--结合Align给多个子控件布局
 * 
 */
class  MyStackLayout02 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Center(
      child: Container(
        height: 400,
        width: 300,
        color: Colors.yellow,
        child: Stack(
        // alignment: Alignment.center,
        // Alignment这里面的参数,x,y是-1到1之间变化,就可以达到定位的效果
        alignment: Alignment(-1,1),
        children: <Widget>[
          Align(
            alignment: Alignment(0, 0),
            child: Icon(Icons.home,size: 40,color: Colors.blue,),
          ),
           Align(
            alignment: Alignment(0, 1),
            child: Icon(Icons.select_all,size: 40,color: Colors.green,),
          ),
           Align(
            alignment: Alignment(1, 0),
            child: Icon(Icons.satellite,size: 40,color: Colors.red,),
          ),
           Align(
            alignment: Alignment(1, 1),
            child: Icon(Icons.save,size: 40,color: Colors.pink,),
          ),

        ],
      ),
      ),
    );
  } 
}


/**
 * 
 * Stack组件--结合Positioned给多个子控件布局
 * 
 */
class  MyStackLayout03 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Center(
      child: Container(
        height: 400,
        width: 300,
        color: Colors.yellow,
        child: Stack(
        // alignment: Alignment.center,
        // Alignment这里面的参数,x,y是-1到1之间变化,就可以达到定位的效果
        alignment: Alignment(-1,1),
        children: <Widget>[
          Positioned(
            left: 0,
            top: 0,
            child: Icon(Icons.home,size: 40,color: Colors.blue,),
          ),
           Positioned(
            right: 0,
            top: 0,
            child: Icon(Icons.select_all,size: 40,color: Colors.green,),
          ),
           Positioned(
            bottom: 0,
            child: Icon(Icons.satellite,size: 40,color: Colors.red,),
          ),
           Positioned(
            bottom: 0,
            right: 0,
            child: Icon(Icons.save,size: 40,color: Colors.pink,),
          ),

        ],
      ),
      ),
    );
  } 
}

/**
 * 
 * AspectRatio组件
 */
class  MyAspectRatio extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return AspectRatio(
      // aspectRatio 表示宽高比,  这里宽是占满整屏幕的
      aspectRatio: 3.0/1.0,
      child: Container(
        color: Colors.red,
      ),
      
    );
  }
}

/**
 * 卡片布局 -- Card
 */

class  MyCard01 extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return ListView(
      children: <Widget>[
        Card(
          margin: EdgeInsets.all(10),
          child: Column(
            children: <Widget>[
              ListTile(
                title: Text(
                  "张三",
                  style: TextStyle(fontSize: 28),
                  ),
                  subtitle: Text("高级工程师傅"),
              ),
              ListTile(
                title: Text("电话:XXXXXX"),
              ),
              ListTile(
                title: Text("地址:XXXXXX"),
              ),
              
            ],
          ),
        ),
         Card(
          margin: EdgeInsets.all(10),
          child: Column(
            children: <Widget>[
              ListTile(
                title: Text(
                  "张三",
                  style: TextStyle(fontSize: 28),
                  ),
                  subtitle: Text("高级工程师傅"),
              ),
              ListTile(
                title: Text("电话:XXXXXX"),
              ),
              ListTile(
                title: Text("地址:XXXXXX"),
              ),
              
            ],
          ),
        )
        
      ],
    );
  }
  
}



/**
 * 卡片布局 -- Card -- 具有图文的卡片
 */

class  MyCard02 extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return ListView(
      children: <Widget>[
        Card(
          margin: EdgeInsets.all(10),
          child: Column(
            children: <Widget>[
              AspectRatio(
              // 纵横比例
                aspectRatio: 20/9,
                child: Image.network("https://www.itying.com/images/flutter/2.png",fit: BoxFit.cover,),
              ),
              ListTile(
                // CircleAvatar这个控件专门设置头像的
                leading: CircleAvatar(
                  backgroundImage: NetworkImage("https://www.itying.com/images/flutter/1.png"),
                ),
                title: Text("姓名:xxxxxxxx"),
                subtitle: Text("电话:xxxxxx"),
              )
            ],
          ),
        ),
         Card(
          margin: EdgeInsets.all(10),
          child: Column(
            children: <Widget>[
              AspectRatio(
                aspectRatio: 20/9,
                child: Image.network("https://www.itying.com/images/flutter/2.png",fit: BoxFit.cover,),
              ),
              ListTile(
                // ClipOval实现圆图片
                leading: ClipOval(
                  
                  child: Image.network("https://www.itying.com/images/flutter/3.png",height: 40,width: 40,fit: BoxFit.cover,),
                  
                ),
                title: Text("姓名:xxxxx"),
                subtitle: Text("电话:xxxxx"),

              )
            ],
          ),
        )
        
      ],
    );
  }
}


class MyWrapLayout01 extends StatelessWidget{
  @override
  Widget build(BuildContext context) {

    return Container(
      color: Colors.yellow,
      height: 600,
      width: double.infinity, // 这个写法就是表示占满整个屏幕
      child: Wrap(
        spacing: 10,// 间距
        // runSpacing: 10,  // 垂直方向间距
        alignment: WrapAlignment.start,  // 左对齐方式
        // direction: Axis.vertical,  // 垂直方向排列
        children: <Widget>[
          MyRaisedButton("第1集"),
          MyRaisedButton("第10集"),
          MyRaisedButton("第110集"),
          MyRaisedButton("第1101集"),
          MyRaisedButton("第1123集"),
          MyRaisedButton("第1543集"),
          MyRaisedButton("第1435集"),
          MyRaisedButton("第154325集"),
          MyRaisedButton("第15435集"),
          MyRaisedButton("第153245集"),
          MyRaisedButton("第431集"),
        ],
      )
    );
    // TODO: implement build
    
  }
}


/**
 * 按钮组件RaisedButton
 */
class MyRaisedButton extends StatelessWidget{
  final String text;
  const MyRaisedButton(this.text,{Key key});
  // const MyRaisedButton(this.text,{Key key});
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return RaisedButton(
      child: Text(this.text), 
      onPressed: () {
        print(this.text);
      },
      textColor: Theme.of(context).accentColor
    );
  }
}