
import 'Home/smallPark.dart';
import 'Home/home.dart';
import 'Search.dart';
import 'package:flutter/material.dart';
import '../pages/Home/goods.dart';
import '../pages/Home/goodsInfo.dart';
import '../pages/Home/tabarController.dart';
import '../pages/Home/button.dart';
import '../pages/Home/TextField.dart';
import '../pages/Home/CheckBox.dart';
import '../pages/Home/Radio.dart';
import '../pages/Home/FormDemo.dart';
import '../pages/Home/DateTest.dart';
import '../pages/Home/dialog.dart';

final routes = {
          '/home': (content)=>MyStateFul02(),
          '/smallPark':(content)=>SmallPark(),
          '/search':(content,{arguments})=>SearchPage(arguments:arguments),
          '/goods': (content)=>Goods(),
          '/goodsInfo':(content,{arguments})=>GoodsInfo(arguments:arguments),
          '/tabbarController': (content)=>TabbarController(),
          '/button' : (content)=>Button(),
          '/textField': (content)=>TextFild_test(),
          '/checkBox': (content)=>CheckBox(),
          '/radio': (content)=>RadioTest(),
          '/formDemoPage': (content)=>FormDemoPage(),
          '/dateTest': (content)=>DateTest(),
          '/dialog': (content)=>DialogTest(),
   };
var onGenerateRoute = (RouteSettings settings) { // 统一处理
        final String name = settings.name;
        final Function pageContentBuilder = routes[name];
        if (pageContentBuilder != null) {
            if(settings.arguments != null){
                final Route route = MaterialPageRoute(
                    builder: (context) =>
                    pageContentBuilder(context, arguments: settings.arguments));
                return route; 
            }else{
              final Route route = MaterialPageRoute(
                builder: (context)=>
                    pageContentBuilder(context)
              );
              return route;
            }
      
    }
 };