import 'package:flutter/material.dart';


class TextFild_test extends StatefulWidget {
  TextFild_test({Key key}) : super(key: key);

  _TextFild_testState createState() => _TextFild_testState();
}

class _TextFild_testState extends State<TextFild_test> {
  
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
       appBar: AppBar(
         title: Text("各种文本框"),
       ),
       body: TextDemo01(),
    );
  }
}

class TextDemo01 extends StatelessWidget {
  const TextDemo01({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(10),
      child: Column(
        children: <Widget>[
          TextField(),
          SizedBox(height: 10,),
          TextField(
          
            decoration: InputDecoration(
            
              hintText: "请输入搜索的内容",
              border: OutlineInputBorder()
            ),
          ),
          SizedBox(height: 10,),
          TextField(
            maxLines: 4,
            decoration: InputDecoration(
              hintText: "多行文本框",
              border: OutlineInputBorder(), // 实线边框
            ),
          ),
          SizedBox(height: 10,),
          TextField(
            obscureText: true,   
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              labelText: "边框带文字-密码"   // 变宽有文字
            ),
          ),
          SizedBox(height: 10),
          TextField(             
              decoration:InputDecoration(               
                border: OutlineInputBorder(),
                labelText: "边框带文字"   // 变宽有文字
              ) 
            ),
             SizedBox(height: 20),
             TextField(
               decoration: InputDecoration(
                 icon: Icon(Icons.people),
                 hintText: "带图片的框"
               ),
             )
        ],
      ),


    );
  }
}

class TextDemo02 extends StatefulWidget {
  TextDemo02({Key key}) : super(key: key);

  _TextDemo02State createState() => _TextDemo02State();
}

class _TextDemo02State extends State<TextDemo02> {
  var _userName = new TextEditingController();
  var _password  = new TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _userName.text = '初始值';
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
         padding: EdgeInsets.all(20),
         child: Column(
         children: <Widget>[
            TextField(
              
              decoration: InputDecoration(
                hintText: "请输入用户名"
              ),
              controller: _userName,
              onChanged: (value){
                setState(() {
                  _userName.text = value;
                });
              },
            ),
            SizedBox(height: 20,),
            TextField(
              obscureText: true,
              decoration: InputDecoration(
                hintText: "密码"
              ),
              controller: _password,
              onChanged: (value){
                setState(() {
                  _password.text = value;
                });
              },
            ),
            SizedBox(height: 20,),
            Container(
              width: double.infinity,
              height: 40,
              child: RaisedButton(
                child: Text("登录"),
                onPressed: (){
                  print(this._userName.text);
                  print(this._password.text);
                },
              ),
              )

        ],
    
       ),
      );
  }
}