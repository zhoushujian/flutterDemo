import 'package:flutter/material.dart';

class SmallPark extends StatelessWidget {
  String title;
  SmallPark({this.title});  // 传值,这个构造函数必须要有
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // 添加一个浮动按钮
      floatingActionButton: FloatingActionButton(
        child: Text("返回"),
        onPressed: () {
          Navigator.of(context).pop("嘻嘻哈哈");
        },
        
      ),
      appBar: AppBar(
        title: Text(this.title),
      ),
      body: Text("这里面都放小猫停车"),
    );
  }
}