import 'dart:collection';
import 'package:flutter/material.dart';
// import 'package:flutter_baidu_map/flutter_baidu_map.dart';
// import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_amap/flutter_amap.dart';
import 'package:newflutterdemo/pages/Home/BookingParking/model/homeBookingModel.dart';
import 'immediatelyBooking.dart';

HomeBookingModel data_model;
List fee;
class ParkingBooking extends StatefulWidget {
  HomeBookingModel model;
  ParkingBooking({this.model});

  _ParkingBookingState createState() => _ParkingBookingState(this.model);
}

class _ParkingBookingState extends State<ParkingBooking> {
  HomeBookingModel model;
  _ParkingBookingState(this.model);
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    data_model = this.model;
    listDeal();
  }

// 
  listDeal(){
    
    setState(() {
      fee = model.sketch.split(",");
    });
  }
   @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("车位预约"),
      ),
      body: MyListView01(model: this.model,),
    );
  }
}




class MyListView01 extends StatelessWidget {
  HomeBookingModel model;
   FlutterAmap amap = new FlutterAmap();
   MyListView01({this.model});
     void show(){
    amap.show(
        mapview: new AMapView(
            centerCoordinate: new LatLng(39.9242, 116.3979),
            zoomLevel: 13.0,
            mapType: MapType.night,
            showsUserLocation: true),
        title: new TitleOptions(title: "我的地图"));
    amap.onLocationUpdated.listen((Location location){

      print("Location changed $location") ;

    });
  }
  @override
  Widget build(BuildContext context) {
    return ListView(
        children: <Widget>[
           Container(
            padding: EdgeInsets.only(left: 10,top: 8),
             height: 34,
             child: Text( 
               "停车场详情"
               ),
             color: Colors.orange,
           ),
           Container(
             padding: EdgeInsets.only(left: 10,top: 8),
             height: 34,
             child: Text(model.parkingName),
           ),
           Divider(),
            Container(
              padding: EdgeInsets.only(left: 10,top: 8),
             height: 34,
             child: Text(model.address),
           ),
           Divider(),
            Container(
              padding: EdgeInsets.only(left: 10,top: 8),
             height: 34,
             child: Text("可预约车位:"+model.resvNum.toString()+"个"),
           ),
           Divider(),
        
           Container(
             padding: EdgeInsets.only(left: 10,top: 8),
             height: 34,
             child: Text("临时收费规则"),
             color: Colors.orange,
           ),
           Divider(),

         
          Container(
              //Text(fee[index])
             height: 140,
             child:   ListView.builder(
              physics: new NeverScrollableScrollPhysics(),
             itemCount: fee.length,
              itemBuilder: (context,index){
                return Column(
                  children: <Widget>[
                    ListTile(
                      title: Text(fee[index]),
                    ),
                    Divider(), 
                  ],
                );
              
              },

           ),
           ),
    
           SizedBox(height: 30,),

           Container(
             margin: EdgeInsets.all(20),
              child: RaisedButton(
                color: Colors.orange,
                textColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)   // 切圆角
                ),
                onPressed: (){
                   Navigator.push<Object>(
                        context,
                        MaterialPageRoute(
                        builder: (BuildContext context) {
                            return new ImmediatelyBooking(model: this.model,);
                        },
                      )
                    );
                        
                },
                child: Text("预         约"),
                elevation:6,  // 数值越大,阴影越大
              ),
           ),
           
          Container(
            // child: AMapView(),
          )
             
          
        ],
    );
  }
}




List titleArr = [
  "停车场详情",
  "临时收费规则",
];