import 'package:flutter/material.dart';
import 'package:newflutterdemo/components/listViewMessage.dart';

class MessagePage extends StatefulWidget {
  MessagePage({Key key}) : super(key: key);

  _MessagePageState createState() => _MessagePageState();
}

class _MessagePageState extends State<MessagePage> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
      appBar:AppBar(
        
        title: Text("预约信息"),
        centerTitle: true,
        // backgroundColor: Colors.blue,
          bottom: TabBar(
            
            unselectedLabelColor:Colors.black,  // 未选中的颜色
            indicatorColor: Colors.orange,// 选中的颜色
            labelColor: Colors.white,
            
            tabs: <Widget>[
              Tab(text: "预约中",),
              Tab(text: "预约完成",),
              Tab(text: "预约取消",),
            ],
          ),
      ),
      body: TabBarView(
        children: <Widget>[
            CompleteListView(
              btn_title: "预约",
            ),
            CompleteListView(
              btn_title: "已完成",
            ),
            CompleteListView(
              btn_title: "已取消",
            ),
          
        ],
      ),
      
    ), 
    );
  }
}

