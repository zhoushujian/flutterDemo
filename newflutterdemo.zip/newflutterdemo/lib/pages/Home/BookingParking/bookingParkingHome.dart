import 'dart:io';

import 'package:flutter/material.dart';
import 'package:newflutterdemo/pages/Home/BookingParking/NetWork/NetUtil.dart';
import 'package:newflutterdemo/pages/Home/BookingParking/message.dart';
import 'package:newflutterdemo/pages/Home/BookingParking/model/homeBookingModel.dart';
import 'parkingBooking.dart';
import 'dart:convert';
import 'package:sy_flutter_wechat/sy_flutter_wechat.dart';

// List netData_list = [];

// import 'package:flutter_amap/flutter_amap.dart';
// import 'package:flutter_amap/location.dart';

class BookingParkingHome extends StatefulWidget {
  BookingParkingHome({Key key}) : super(key: key);

  _BookingParkingHomeState createState() => _BookingParkingHomeState();
}

class _BookingParkingHomeState extends State<BookingParkingHome> {
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
      // NetUtil().fetchPost("/resv/getparkingList", {});
      loadData();

  }
  loadData(){
      HomeDao.fetch().then((result){
          print(result.dataList);
         
          setState(() {
             listData = result.dataList;
          });
      });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("车位预约"),
        actions: <Widget>[
          FlatButton(
            child: Text("记录查询"),
            color: Colors.orange,
            onPressed: () async{
                Navigator.push<Object>(
                context,
                MaterialPageRoute(
                builder: (BuildContext context) {
                    return new MessagePage();
                },
            ),
                  
              );
                // print("来了老弟");
                // String payInfo =
                //     '{"appid":"wx9f570951a27f8d97","partnerid":"1518469211","prepayid":"wx120649521695951d501636f91748325073","package":"Sign=WXPay","noncestr":"1541976592","timestamp":"1541976592","sign":"E760C99A1A981B9A7D8F17B08EF60FCC"}';
                // SyPayResult payResult = await SyFlutterWechat.pay(
                //     SyPayInfo.fromJson(json.decode(payInfo)));
                // print("---"+'{$payResult}');
                //  print("是呀");

            },
          )
          
        ],
        
      ),
      body: TabelView(),
    );
  }
}


 List<HomeBookingModel> listData = [];
     
    


class TabelView extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
     return  MyListView();
  }
}


class MyListView extends StatelessWidget {
  const MyListView({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: ListView(
      children: listData.map((value){
        return Card(
          margin: EdgeInsets.all(10),
          child: Row(
            children: <Widget>[
              Container(
                width: 300,
                child: Column(
                    children: <Widget>[
                      Container(
                        margin: EdgeInsets.fromLTRB(10, 10, 0, 0),
                        // alignment: Alignment.topLeft,
                        
                        child: Text(
                          value.parkingName,
                          textAlign: TextAlign.left,
                          style: TextStyle(
                              fontSize: 14
                           ),
                          
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(10, 5, 0, 0),
                        alignment: Alignment.topLeft,
                        child: Text(
                          value.address
                          ),
                        
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(10, 5, 0, 0),
                        alignment: Alignment.topLeft,
                        child: Text(
                          value.distance
                          ),
                        
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(10, 5, 0, 10),
                        alignment: Alignment.topLeft,
                        child: Text(
                          value.sketch,
                          
                        )
                      ),
                    ]
              ),
              ),
              Container(
                  // margin: EdgeInsets.fromLTRB(50, 20, 10, 50),
                  child: RaisedButton(
                    child: Text("预约"),
                    color: Colors.orange,
                    onPressed: (){
                        Navigator.push<Object>(
                        context,
                        MaterialPageRoute(
                        builder: (BuildContext context) {
                            return new ParkingBooking(model: value,);
                        },
                    ),
                  
              );
                    },
                 )
              ),
              
            ]
          )
        ); 
      }).toList() ,
     ),
    );
  }
}


class TabelView02 extends StatelessWidget {
  const TabelView02({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Stack(
        children: <Widget>[
          Text(
            "我是一个文本",
            

            ),
          Text("我是一个文本22"),
          Text("我是一个文本454"),
          Text("我是一个文本54题4"),
        ],
      ),
    );
  }
}

/**
 * 
 * Stack组件,  自由定位子控件,相当于前端的悬浮
 * 
 */
class  MyStackLayout01 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Center(
      child: Stack(
        // alignment: Alignment.center,
        // Alignment这里面的参数,x,y是-1到1之间变化,就可以达到定位的效果
        alignment: Alignment(-1,1),
        children: <Widget>[
          Container(
            height: 400,
            width: 300,
            color: Colors.red,

          ),
          Text("我是一个文本"),
          Text("我是一个文本22"),
          Text("我是一个文本454"),
          Text("我是一个文本54题4"),

        ],
      ),
    );
  }
  
}

