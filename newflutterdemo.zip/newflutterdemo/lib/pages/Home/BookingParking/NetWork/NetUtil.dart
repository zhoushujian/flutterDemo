
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:newflutterdemo/pages/Home/BookingParking/model/homeBaseModel.dart';
import 'dart:convert' as convert;

import 'package:newflutterdemo/pages/Home/BookingParking/model/homeBookingModel.dart';
import 'package:newflutterdemo/pages/Home/BookingParking/model/payModel.dart';
import 'package:newflutterdemo/pages/Home/BookingParking/parkingBooking.dart';
final host = 'http://120.77.237.179:4004';

class NetUtil {
  static final debug = true;
  static BuildContext context = null;
  
  // List<HomeBookingModel> data_arr_list;
  var data_arr_list = List<HomeBookingModel>();
  fetchPost(String api,Map pragma) async{
     var url = host + api;
    // var map = new Map<String, dynamic>();
  // Await the http get response, then decode the json-formatted responce.
      var response =  await http.post(
        url,
        headers: {HttpHeaders.contentTypeHeader: 'application/json'},
         body: convert.jsonEncode(pragma));
      if (response.statusCode == 200) {
        var jsonResponse = convert.jsonDecode(response.body);
        if(jsonResponse["flag"] == 1){
            print(jsonResponse["data"]);
            var data_map = jsonResponse["data"];
            List data_list = data_map["resvParkingRespList"];
            for (var item in data_list) {
              HomeBookingModel model = HomeBookingModel.fromJson(item);
              data_arr_list.add(model);
              
            }
            // print(data_arr_list);
            return data_arr_list;
        }else{
            print(jsonResponse["msg"]);
        }
      } else {
        print("Request failed with status: ${response.statusCode}");
      }
  }
}

class HomeDao{
   
   static Future<HomeBaseModel> fetch() async{
     var url_2 = host + "/resv/getparkingList";
     var response =  await http.post(
        url_2,
        headers: {HttpHeaders.contentTypeHeader: 'application/json'},
         body: convert.jsonEncode({}));
     if(response.statusCode == 200){
       var jsonResponse = convert.jsonDecode(response.body);
       if(jsonResponse["flag"] == 1){
          // print(jsonResponse["data"]);
          return HomeBaseModel.fromJson(jsonResponse["data"]);
      }
       
     }else{
        throw Exception("失败了");
     }
   }

}

// 预约车位下订单
class BookPay{
  
  static Future<PayModel> fetch() async{
     var url_2 = host + "/resv/operate";
     // 参数
   Map pramage = {
     "carNum":"粤B654321",
     "parkId":data_model.parkId,
     "smallId":"139252925501438664655",
     "tel":"13212345678"
   };
     var response =  await http.post(
        url_2,
        headers: {HttpHeaders.contentTypeHeader: 'application/json'},
         body: convert.jsonEncode(pramage));
     if(response.statusCode == 200){
       var jsonResponse = convert.jsonDecode(response.body);
       if(jsonResponse["flag"] == 1){
          print(jsonResponse["data"]);
          return PayModel.fromJson(jsonResponse["data"]);
      }else{
        return null;
      }
       
     }else{
        throw Exception("失败了");
     }
   }

}



// 小猫支付
class MallPay{

  PayModel pay_model;
  MallPay({pay_model});
  Future<PayModel> fetch() async{
     var url_2 = host + "/resvPay/small";
     // 参数
   Map pramage = {
     "carNum":pay_model.carNum,
     "orderId":pay_model.orderId,
     "totalFee": pay_model.totalFee.toString(),

   };
   print(pay_model.carNum);
   print(pay_model.orderId);
   print(pay_model.totalFee.toString());
     var response =  await http.post(
        url_2,
        headers: {HttpHeaders.contentTypeHeader: 'application/json'},
         body: convert.jsonEncode(pramage));
     if(response.statusCode == 200){
       var jsonResponse = convert.jsonDecode(response.body);
       if(jsonResponse["flag"] == 1){
          print(jsonResponse["data"]);
          // return PayModel.fromJson(jsonResponse["data"]);
      }else{
        return null;
      }
       
     }else{
        throw Exception("失败了");
     }
   }

}