// 成功预约
import 'package:flutter/material.dart';
import 'package:newflutterdemo/components/myDialog.dart';

class SuccessBooked extends StatefulWidget {
  
  SuccessBooked({Key key}) : super(key: key);

  
  _SuccessBookedState createState() => _SuccessBookedState();
}


class _SuccessBookedState extends State<SuccessBooked> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("预约结果"),
      ),
      body: MySuccessListView(),
    );
  }
}

class MySuccessListView extends StatefulWidget {
  MySuccessListView({Key key}) : super(key: key);

  _MySuccessListViewState createState() => _MySuccessListViewState();
}

class _MySuccessListViewState extends State<MySuccessListView> {
  @override
  Widget build(BuildContext context) {
    return ListView(
        children: <Widget>[
            Container(
              height: 80,
              // color: Colors.pink,
              
              child: Center(
              child: Text(
                
                "预约成功",
                style: TextStyle(
                    fontSize: 32,
                    color: Colors.green,
                    fontWeight: FontWeight.bold
                   ),
                ),
            ),
          ),
          Container(
              child: MessageListView(),
          ),
          Container(
            height: 100,
            padding: EdgeInsets.only(left: 12,top: 30,right: 12),
            child: Text("温馨提示:\n1, 降锁验证码在进行降锁操作时使用,请注意保管\n2, 请注意预留时间,在预约结束时间前到达"),
          ),
          Container(
            height: 80,
            
            padding: EdgeInsets.only(left: 12,top: 30,right: 12),
            child: RaisedButton(
              color: Colors.orange,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10)
              ),
              onPressed: (){
                  showDialog(
                    context: context,
                    builder: (context){
                      return MyDialog(
                        title: "温馨提示",
                        content: "有且仅有一次降锁机会,请确认到达车位后再进行降锁操作,以免车位被其他车主占用",
                      );
                    }
                  );
              },
              child: Text("车 位 降 锁"),
            ),
          ),
            
        ],
    );
  }
}

class MessageListView extends StatefulWidget {
  MessageListView({Key key}) : super(key: key);

  _MessageListViewState createState() => _MessageListViewState();
}

class _MessageListViewState extends State<MessageListView> {
  List<String> listTitle = [
  "预约车牌",
  "停车场名",
  "预约金额",
  "车位位置",
  "预约开始时间",
  "预约结束时间",
  "订单编号"
];

List <String>listContent =[
  "粤B 122334",
  "创新大厦停车场",
  "5元",
  "B1-B区-01",
  "2019-09-19 18:00:00",
  "2019-09-19 18:30:00",
  "2019354678976546786"
];

final List<String> entries = <String>['A', 'B', 'C'];
final List<int> colorCodes = <int>[600, 500, 100];

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 260,
      color: Color.fromRGBO(213, 213, 213, 1),
      child: ListView.builder(
        
      padding: const EdgeInsets.all(12.0),
      itemCount: listTitle.length,
      itemBuilder: (BuildContext context, int index) {
        return Container(
          height: 30,
          // color: Colors.amber[colorCodes[index]],
          child: Row(
              children: <Widget>[
                Text('${listTitle[index]}:'),
                SizedBox(width: 30,),
                Text('${listContent[index]}')
              ],
          )
          
        );
      }
    )
      
    );
  }
}

