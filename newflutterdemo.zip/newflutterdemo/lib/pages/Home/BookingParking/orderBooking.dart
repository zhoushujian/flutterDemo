// 预约信息 -- 订单信息
import 'package:flutter/material.dart';
import 'package:newflutterdemo/pages/Home/BookingParking/model/payModel.dart';
import 'package:newflutterdemo/pages/Home/BookingParking/successBooked.dart';

import 'NetWork/NetUtil.dart';

PayModel pay_model;

class OrderBooking extends StatefulWidget {
  PayModel model;
  OrderBooking({this.model});
  _OrderBookingState createState() => _OrderBookingState(model:this.model);
}

class _OrderBookingState extends State<OrderBooking> {
  PayModel model;
  _OrderBookingState({this.model});

  @override
  void initState() { 
    super.initState();
    pay_model = this.model;
     print(pay_model.carNum);
     print(pay_model.parkName);
    print(pay_model.lotNum);
    print(pay_model.resvDate);
    print(pay_model.resvTime.toString()+"分钟");
    print(pay_model.totalFee);
    print(pay_model.orderId);
    
    
  }
  @override
  Widget build(BuildContext context) {
  WillPopScope(
    onWillPop: (){
        print('onWillPop');
        return Future.value(false);
    },
    child: Container(
        child: Text('haha'),
    ),
    );
    return Scaffold(
      appBar: AppBar(
        title: Text("预约信息"),
        
      ),
      
      body: MyListView(),
    );
  }
}
class WillPopScopeTestRoute extends StatefulWidget {
  @override
  WillPopScopeTestRouteState createState() {
    return new WillPopScopeTestRouteState();
  }
}

class WillPopScopeTestRouteState extends State<WillPopScopeTestRoute> {
  DateTime _lastPressedAt; //上次点击时间

  @override
  Widget build(BuildContext context) {
    return new WillPopScope(
        onWillPop: () async {
          if (_lastPressedAt == null ||
              DateTime.now().difference(_lastPressedAt) > Duration(seconds: 1)) {
            //两次点击间隔超过1秒则重新计时
            _lastPressedAt = DateTime.now();
            return false;
          }
          return true;
        },
        child: Container(
          alignment: Alignment.center,
          child: Text("1秒内连续按两次返回键退出"),
        )
    );
  }
}


class MyListView extends StatefulWidget {
  MyListView({Key key}) : super(key: key);

  _MyListViewState createState() => _MyListViewState();
}

class _MyListViewState extends State<MyListView> {
   _modelBottomSheet() async{
    var result = await showModalBottomSheet(
      context: context,
      builder: (context){
        return Container(
          height: 300,
          child: Column(
            children: <Widget>[
              ListTile(
      
                title: Text("微信支付"),
                onTap: (){
                  Navigator.pop(context,"微信支付 A");

                  Navigator.push<Object>(
                        context,
                        MaterialPageRoute(
                        builder: (BuildContext context) {
                            return new SuccessBooked();
                        },
                      )
                    );
                },
              ),
              Divider(),
              ListTile(
                title: Text("支付宝支付"),
                onTap: (){
                  Navigator.pop(context,"支付宝支付 B");
                },
              ),
              Divider(),
              ListTile(
                title: Text("小猫余额支付"),
                onTap: (){
                  Navigator.pop(context,"小猫余额支付 C");
                  MallPay(pay_model: pay_model).fetch().then((result){
                      print(result);
                  });
                },
              ),
              Divider(),
              ListTile(
                title: Text("银联支付"),
                onTap: (){
                  Navigator.pop(context,"银联支付 D");
                },
              ),
            ],
          ),
        );
      }
    );
    print(result);
  }

  @override
  Widget build(BuildContext context) {
    // return Text("data");
    return ListView(
        children: <Widget>[
           Container(
            padding: EdgeInsets.only(left: 10,top: 12),
             height: 34,
             child: Stack(
               children: <Widget>[
                 Positioned(
                   child: Text("预约车牌: "),
                   left: 5,
                   top: 0,
                 ),
                 Positioned(
                   child: Text(pay_model.carNum),
                   right: 10,
                   top: 0,
                 )
               ],
             )
            
           ),
            Divider(),
           Container(
             padding: EdgeInsets.only(left: 10,top: 8),
             height: 34,
              child: Stack(
               children: <Widget>[
                 Positioned(
                   child: Text("停车场名 :"),
                   left: 5,
                   top: 0,
                 ),
                 Positioned(
                   child: Text(pay_model.parkName),
                   right: 10,
                   top: 0,
                 )
               ],
             ),
           ),
           Divider(),
            Container(
              padding: EdgeInsets.only(left: 10,top: 8),
             height: 34,
             child:  Stack(
               children: <Widget>[
                 Positioned(
                   child: Text("车位位置 :"),
                   left: 5,
                   top: 0,
                 ),
                 Positioned(
                   child: Text(pay_model.lotNum),
                   right: 10,
                   top: 0,
                 )
               ],
             ),
           ),
           Divider(),
            Container(
              padding: EdgeInsets.only(left: 10,top: 8),
             height: 34,
              child: Stack(
               children: <Widget>[
                 Positioned(
                   child: Text("预约日期 :"),
                   left: 5,
                   top: 0,
                 ),
                 Positioned(
                   child: Text(pay_model.resvDate),
                   right: 10,
                   top: 0,
                 )
               ],
             ),
           ),
           Divider(),
            Container(
              padding: EdgeInsets.only(left: 10,top: 8),
             height: 34,
              child: Stack(
               children: <Widget>[
                 Positioned(
                   child: Text("预约时长 :"),
                   left: 5,
                   top: 0,
                 ),
                 Positioned(
                   child: Text(pay_model.resvTime.toString()),
                   right: 10,
                   top: 0,
                 )
               ],
             ),
           ),
           Divider(),
            Container(
              padding: EdgeInsets.only(left: 10,top: 8),
             height: 34,
              child: Stack(
               children: <Widget>[
                 Positioned(
                   child: Text("支付金额 :"),
                   left: 5,
                   top: 0,
                 ),
                 Positioned(
                   child: Text(pay_model.totalFee.toString()+"元"),
                   right: 10,
                   top: 0,
                 )
               ],
             ),
           ),
           Divider(),
        
           Container(
             padding: EdgeInsets.only(left: 10,top: 8),
             height: 34,
              child: Stack(
               children: <Widget>[
                 Positioned(
                   child: Text("订单编号 :"),
                   left: 5,
                   top: 0,
                 ),
                 Positioned(
                   child: Text(pay_model.orderId),
                   right: 10,
                   top: 0,
                 )
               ],
             ),
  
           ),
           Divider(),
           SizedBox(height: 50,),
           Container(
              padding: EdgeInsets.only(left: 20,top: 8,right: 20),
             height: 50,

             child: RaisedButton(
               shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)   // 切圆角
                ),
              color: Colors.orange,
                  onPressed: _modelBottomSheet,
                  child: Text("支  付 (120s)"),
                ),
           ),
           
       ]
    );
  
  }
}


