

class HomeBookingModel{
  final String parkingName;
  final String parkId;
  final String address;
  final String lat;
  final String lng;
  final String sketch;
  final int resvNum;  // 可预约车位数
  final bool openResv;
  final String distance;
  final int reservedTime;
  final double reservationFee;

  // 构造方法,里面加个{}表示可选
  HomeBookingModel({
    this.parkingName,
    this.parkId,
    this.address,
    this.lat,
    this.lng,
    this.sketch,
    this.resvNum,
    this.openResv,
    this.distance,
    this.reservedTime,
    this.reservationFee
  });

  // 工厂方法 -- 实例化
  factory HomeBookingModel.fromJson(Map<String,dynamic> json){
      return HomeBookingModel(
        parkingName: json['parkingName'],
        parkId: json['parkId'],
        address: json['address'],
        lat: json['lat'],
        lng: json['lng'],
        sketch: json['sketch'],
        resvNum: json['resvNum'],
        openResv: json['openResv'],
        distance: '5km',
        reservedTime: json['reservedTime'],
        reservationFee: json['reservationFee'],    
        );
  }
}