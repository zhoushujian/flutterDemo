

import 'package:newflutterdemo/pages/Home/BookingParking/model/homeBookingModel.dart';

class HomeBaseModel {
  final List<HomeBookingModel> dataList;

  HomeBaseModel({this.dataList});

  factory HomeBaseModel.fromJson(Map<String,dynamic> json){
      var localListJson = json['resvParkingRespList'] as List;
      List<HomeBookingModel>  localList = localListJson.map((i) => HomeBookingModel.fromJson(i)).toList();
      return HomeBaseModel(dataList:localList);
  }
}