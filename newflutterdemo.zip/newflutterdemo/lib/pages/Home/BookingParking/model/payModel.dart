// 预付订单生成model
class PayModel {

  final String carNum;  // 车牌号
  final String lotNum;  // 车位编号
  final String orderId;  // 预约订单ID
  final String parkId;    // 停车场id
  final String parkName;  // 停车场名字
  final String resvDate;   // 预约时间
  final int resvTime;  // 预留时长
  final double totalFee;  //预约费用
  
  PayModel({this.carNum,this.lotNum,this.orderId,this.parkId,this.parkName,this.resvTime,this.totalFee,this.resvDate});
  // 工厂方法 -- 实例化
  factory PayModel.fromJson(Map<String,dynamic> json){
      return PayModel(
        carNum: json['carNum'],
        parkId: json['parkId'],
        lotNum: json['lotNum'],
        parkName: json['parkName'],
        orderId:json['orderId'],
        resvDate: json['resvDate'],
        resvTime: json['resvTime'],
        totalFee: json['totalFee'],
      
    );
  }

}