import 'package:flutter/material.dart';
import 'package:newflutterdemo/pages/Home/BookingParking/NetWork/NetUtil.dart';
import 'package:newflutterdemo/pages/Home/BookingParking/model/homeBookingModel.dart';
import 'package:newflutterdemo/pages/Home/BookingParking/model/payModel.dart';
import 'orderBooking.dart';


HomeBookingModel data_model;
class ImmediatelyBooking extends StatefulWidget {
  HomeBookingModel model;
  ImmediatelyBooking({this.model});
  
  _ImmediatelyBookingState createState() => _ImmediatelyBookingState(model);
}

class _ImmediatelyBookingState extends State<ImmediatelyBooking> {
   HomeBookingModel model;
  _ImmediatelyBookingState(this.model,);
  @override
  void initState() { 
    super.initState();
    setState(() {
      data_model = this.model;
       
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("预约"),
        ),
        body: MyListView03(),
    );
  }
}



class MyListView03 extends StatefulWidget {
  MyListView03({Key key}) : super(key: key);

  _MyListView03State createState() => _MyListView03State();
}

class _MyListView03State extends State<MyListView03> {
  PayModel pay_model;
   payOrder(){
    BookPay.fetch().then((result){
         setState(() {
          
           this.pay_model = result;
           if(result != null){
           Navigator.push<Object>(
                                        context,
                                        MaterialPageRoute(
                                        builder: (BuildContext context) {
                                            return new OrderBooking(model: this.pay_model,);
                                        },
                                      )
                                    );
           }
         
         });
      });
  }
  @override
  Widget build(BuildContext context) {
    return ListView(
        children: <Widget>[
           Container(
            padding: EdgeInsets.only(left: 10,top: 8),
             height: 34,
             child: Text( 
               "停车场详情"
               ),
             color: Colors.orange,
           ),
           Container(
             padding: EdgeInsets.only(left: 10,top: 8),
             height: 34,
             child: Text(data_model.parkingName),
           ),
           Divider(),
            Container(
              padding: EdgeInsets.only(left: 10,top: 8),
             height: 34,
             child: Text(data_model.address),
           ),
           Divider(),
            Container(
              padding: EdgeInsets.only(left: 10,top: 8),
             height: 34,
             child: Text("可预约车位:   "+data_model.resvNum.toString()+" 个"),
           ),
           Divider(),
          
        
           Container(
             padding: EdgeInsets.only(left: 10,top: 8),
             height: 34,
             child: Text("预约信息"),
             color: Colors.orange,
           ),
           Divider(),
            Container(
              padding: EdgeInsets.only(left: 10,top: 8),
             height: 34,
             child: Text("预留时长:  "+data_model.reservedTime.toString()+"分钟")
           ),
           Divider(),
           GestureDetector(
             child: Container(
             height: 34,
             padding: EdgeInsets.only(left: 10,top: 8),
             child: Stack(
               children: <Widget>[
                 Positioned(
                   child: Text("预留车牌:"),
                    left: 0,
                    top: 0,
                 ),
                 Positioned(
                   child: Container(
                     child: TextField(
                      
                     decoration: InputDecoration(
                       hintText: "请输入车牌号",
                      
                     ),
                     
                   ),
                      height: 34,
                      width: 150,
                      // color: Colors.red,
                   ),
                  
                   right: 15,
                 )
               ],
             ),
           ),
           onTap: (){
             print("object");
           },
           ),

            
           Divider(),
            Container(
             height: 34,
             padding: EdgeInsets.only(left: 10,top: 8),
             child: Stack(
               children: <Widget>[
                 Positioned(
                   child: Text("手机号码:"),
                    left: 0,
                    top: 0,
                 ),
                 Positioned(
                   child: Container(
                     child: TextField(
                      
                     decoration: InputDecoration(
                       hintText: "请输入手机号",
                        // border: OutlineInputBorder(),
                        
                     ),
                     
                   ),
                      height: 34,
                      width: 150,
                      // color: Colors.red,
                   ),
                  
                   right: 15,
                 )
               ],
             ),
           ),
          //   Divider(),
           SizedBox(height: 30,),
          Container(
            padding: EdgeInsets.all(10),
            child: Text("温馨提示:\n1,支付时间为预约开始时间\n2, 预留时长为30分钟,超时未达到车位,默认本次预留结束,请在预留时间内达到\n3,可直接进入APP降锁或通过短信进入指定页面操作,请谨慎操作"),
          ),
             SizedBox(height: 50,),
             Container(
                // color: Color.fromRGBO(233, 233, 233, 1.0),
                height: 50,
                width: 400,
                child: Row(
                    children: <Widget>[
                      Expanded(
                        flex: 2,
                        child: Container(
                          color:  Color.fromRGBO(233, 233, 233, 1.0),
                          height: 40,
                           child:  Center(
                            child: Text("预约费用: "+data_model.reservationFee.toString()+"元"),
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 1,
                        child: FlatButton(
                          color: Colors.orange,
                              onPressed: (){
                                payOrder();
                                 
                                        
                                },
                              child: Text("立即预约"),
                            ),
                        
                      ),
                    ],
                  ),
              ),
          
        ],
    );
  }
}


