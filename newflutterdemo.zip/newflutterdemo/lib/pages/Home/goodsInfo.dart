// 商品详情页
import 'package:flutter/material.dart';
import '../tabbar.dart';


class GoodsInfo extends StatefulWidget {
  Map arguments;
  GoodsInfo({Key key,this.arguments}) : super(key: key);

  _GoodsInfoState createState() => _GoodsInfoState(arguments:arguments);
}

class _GoodsInfoState extends State<GoodsInfo> {
  Map arguments;
  _GoodsInfoState({this.arguments});
  @override
  Widget build(BuildContext context) {
    return Container(
       child: Scaffold(
         appBar: AppBar(
           title: Text("商品相亲页"),
         ),
         body: Container(
            child: (
              // 
              ListView(
                children: <Widget>[
                    Text("这是商品详情页=${arguments['pId']}"),
                    RaisedButton(
                      onPressed: (){
                        Navigator.of(context).pop();
                        // 直接返回根目录
                        Navigator.of(context).pushAndRemoveUntil(
                          new MaterialPageRoute(builder: (context)=> new Tabbar(index: 1,)), 
                             (route) => route == null
                          );

                       //  Navigator.pushNamedAndRemoveUntil(context, "/home", (route) => route == null);
                      },
                      child: Text("返回"),
                    )
                ],
              )
            ),
            
         ),//
       ),
    );
  }
}
