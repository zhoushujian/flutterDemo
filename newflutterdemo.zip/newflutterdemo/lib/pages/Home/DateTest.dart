import 'package:date_format/date_format.dart'; // 第三方包
import 'package:flutter/material.dart';

class DateTest extends StatefulWidget {
  
  DateTest({Key key}) : super(key: key);

  _DateTestState createState() => _DateTestState();
}

class _DateTestState extends State<DateTest> {
  //  获取当前时间
  DateTime time = DateTime.now();
  int t_test = 1566630032698;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    print(time.millisecondsSinceEpoch);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("日期"),
      ),
      body: Padding(
        padding: EdgeInsets.all(10),
        child: Column(
          children: <Widget>[
            Center(
              // 打印当前时间
              child: Text(this.time.toString()),
            ),
            Center(
              // 获取当前时间戳
              child: Text(this.time.millisecondsSinceEpoch.toString()),
            ),
            Center(
              // 把这个时间戳转换成时间
              child: Text(DateTime.fromMillisecondsSinceEpoch(this.t_test).toString()),
            ),
            Center(

              // 使用第三方
              child: Text(formatDate(DateTime.now(), [yyyy,'年',mm,'月',dd,'日',hh,'时',nn,'分',ss,'秒'])),
            )

          ],
        ),
      ),
    );
  }
}