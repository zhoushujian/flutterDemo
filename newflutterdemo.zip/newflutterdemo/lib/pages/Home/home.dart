import 'package:flutter/material.dart';
import 'smallPark.dart';
import '../Home/BookingParking/bookingParkingHome.dart';
/**
 * 有状态组件 点击按钮实现改变数据01
 */
class MyStateFul02 extends StatefulWidget {
  MyStateFul02({Key key}) : super(key: key);

  _MyStateFul02State createState() => _MyStateFul02State();
}

class _MyStateFul02State extends State<MyStateFul02> {
  List list = new List();
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("首页"),
          actions: <Widget>[
           
           IconButton(
              icon: Icon(Icons.more_horiz), tooltip: "more_horiz", onPressed: (){
                 Navigator.push<Object>(
                        context,
                        MaterialPageRoute(
                        builder: (BuildContext context) {
                            return new BookingParkingHome();
                        },
                    ));
              }
            )
         ],
        ),
        
        body: ListView(
          children: <Widget>[
            Column(
              children: this.list.map((value){
                return ListTile(
                  title: Text(value),
                );
              }).toList(),
            ),
            RaisedButton(
              onPressed: () {
                setState(() {
                  this.list.add("添加一条数据01");
                });
              
              },
              child: Text("点击按钮添加一条数据"),
              
            ),
            RaisedButton(
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (BuildContext context) => SmallPark(title:"我是跳转传值")
                    
                  )
                );
              },
              child: Text("小猫停车"),
            ),
            RaisedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/search',arguments: {
                  "id":123
                });
              },
              child: Text("跳转到搜索页"),
            ),
            RaisedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/goods');
              },
              child: Text("跳转到商品页"),
            ),
            RaisedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/tabbarController');
              },
              child: Text("TabbarController实现Tab切换"),
            ),
            RaisedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/button');
              },
              child: Text("各种按钮控件"),
            ),
            RaisedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/textField');
              },
              child: Text("各种TextField"),
            ),
            RaisedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/checkBox');
              },
              child: Text("CheckBox"),
            ),
            RaisedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/radio');
              },
              child: Text("Radio--勾选框"),
            ),
            RaisedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/formDemoPage');
              },
              child: Text("表单的Demo"),
            ),
            RaisedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/dateTest');
              },
              child: Text("时间相关-Date"),
            ),
            RaisedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/dialog');
              },
              child: Text("各种弹窗-dialog"),
            )
          ],
    ),
  );
    
    
    
    
    
  }
}
