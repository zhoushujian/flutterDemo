import 'package:flutter/material.dart';

class Goods extends StatefulWidget {
  Goods({Key key}) : super(key: key);

  _GoodsState createState() => _GoodsState();
}

class _GoodsState extends State<Goods> {
  @override
  Widget build(BuildContext context) {
    return Container(
       child: Scaffold(
         appBar: AppBar(
           title: Text("商品页"),
         ),
         body: RaisedButton(
         
           child: Text("跳转到商品详情页"),
           onPressed: () {
              Navigator.pushNamed(context, '/goodsInfo',arguments: {
                'pId':"xixihaha"
              });
              // Navigator.pushReplacementNamed(context, '/goodsInfo',arguments: {
              //   'pId':"xixihaha"
              // });
           },
            
         ),
       ),
    );
  }
}