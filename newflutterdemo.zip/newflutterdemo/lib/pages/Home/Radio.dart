import 'package:flutter/material.dart';

class RadioTest extends StatefulWidget {
  RadioTest({Key key}) : super(key: key);

  _RadioTestState createState() => _RadioTestState();
}

class _RadioTestState extends State<RadioTest> {
   bool flag = true;
  int sex = 1;
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Radio"),
      ),
      body: Padding(
        padding: EdgeInsets.all(10),
        child: Column(
          children: <Widget>[
             Divider(),
        
                RadioListTile(
                  groupValue: this.sex, 
                  title: Text("标题"),
                  subtitle: Text("二级标题"),
                  secondary: Image.network("https://www.itying.com/images/flutter/2.png"),
                  selected: this.sex == 1,
                  onChanged: (value) {
                    setState(() {
                      this.sex = value;
                    });
                  }, 
                  value: 1,
                  
                ),
                 RadioListTile(
                  groupValue: this.sex, 
                  title: Text("标题"),
                  selected: this.sex == 2,
                  subtitle: Text("二级标题"),
                  secondary: Image.network("https://www.itying.com/images/flutter/2.png"),
                  onChanged: (value) {
                    setState(() {
                      this.sex = value;
                    });
                  }, 
                  value: 2,
                  
                ),
                Divider(),
                SizedBox(height: 10,),
                  Switch(
                    value: this.flag,
                    onChanged: (v){
                      setState(() {
                        this.flag = v;
                      });
                    },
                  )
                 
              ],
            ),
            
          
        
      ),
    );
  }
}