import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../../components/myDialog.dart';

class DialogTest extends StatefulWidget {
  DialogTest({Key key}) : super(key: key);

  _DialogTestState createState() => _DialogTestState();
}

class _DialogTestState extends State<DialogTest> {
  _alertDialog() async{
    var result = await showDialog(
      barrierDismissible: false,  //表示点击灰色背景的时候是否消失弹出框
      context: context,
      builder: (context){
        return AlertDialog(
          title: Text("提示信息!"),
          content: Text("您确定要删除吗?"),
          actions: <Widget>[
            FlatButton(
              child: Text("取消"),
              onPressed: (){
                print("取消");
                Navigator.pop(context,'Cancle');
              },
            ),
            FlatButton(
              child: Text("确定"),
              onPressed: (){
                print("确定");
                Navigator.pop(context,'of');
              },
            )
          ],
        );
      }
    );
    print(result);
  }

  _simpleDialog () async{
    var result = await showDialog(
      barrierDismissible: true,
      context: context,
      builder: (context){
        return SimpleDialog(
          title: Text("选择内容"),
          children: <Widget>[
            SimpleDialogOption(
              child: Text("Option A"),
              onPressed: (){
                print("Opetion A");
                Navigator.pop(context,"A");
              },
            ),
            Divider(),
            SimpleDialogOption(
              child: Text("Option B"),
              onPressed: (){
                print("Opetion B");
                Navigator.pop(context,"B");
              },
            ),
            Divider(),
            SimpleDialogOption(
              child: Text("Option C"),
              onPressed: (){
                print("Opetion C");
                Navigator.pop(context,"C");
              },
            ),
            Divider(),
          ],
        );
      }
    );
    print(result);
  }

// 从底部弹出
  _modelBottomSheet() async{
    var result = await showModalBottomSheet(
      context: context,
      builder: (context){
        return Container(
          height: 220,
          child: Column(
            children: <Widget>[
              ListTile(
                title: Text("分享 A"),
                onTap: (){
                  Navigator.pop(context,"分享 A");
                },
              ),
              Divider(),
              ListTile(
                title: Text("分享 B"),
                onTap: (){
                  Navigator.pop(context,"分享 B");
                },
              ),
              Divider(),
              ListTile(
                title: Text("分享 C"),
                onTap: (){
                  Navigator.pop(context,"分享 C");
                },
              ),
            ],
          ),
        );
      }
    );
    print(result);
  }

  _toast(){
    Fluttertoast.showToast(
        msg: "提示信息",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,  // 位置
        timeInSecForIos: 3,
        backgroundColor: Colors.black,
        textColor: Colors.white,
        fontSize: 16.0
    );
  }
  @override
  Widget build(BuildContext context) {
    return Container(
       child: Scaffold(
         appBar: AppBar(
           title: Text("对话框"),
         ),
         body: Center(
           child: Column(
             mainAxisAlignment:MainAxisAlignment.center,
             children: <Widget>[
               RaisedButton(
                 child: Text("alert弹出框-AlertDialog "),
                 onPressed: _alertDialog,
               ),
               RaisedButton(
                 child: Text("select弹出框-SimpleDialog"),
                 onPressed: _simpleDialog,
                 
               ),
               RaisedButton(
                 child: Text("ActionSheet底部弹出框-showModalBottomSheet"),
                 onPressed: _modelBottomSheet,
                 
               ),
               SizedBox(height: 10),
               RaisedButton(
                child: Text('toast-fluttertoast第三方库'),
                onPressed: _toast,
              ),
              SizedBox(height: 10),
               RaisedButton(
                child: Text('自定义弹窗'),
                onPressed: (){
                  // 显示自定义弹窗
                  showDialog(
                    context: context,
                    builder: (context){
                      return MyDialog(
                        title: "温馨提示",
                        content: "有且仅有一次降锁机会,请确认到达车位后再进行降锁操作,以免车位被其他车主占用",
                      );
                    }
                  );
                }
              ),
              
             ],
           ),
         ),
       ),
    );
  }
}