import 'package:flutter/material.dart';

class Button extends StatelessWidget {
  const Button({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("各种按钮"),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: (){
          print("浮动按钮");
        },
        child: Icon(Icons.add,color: Colors.black,size: 44,),
        backgroundColor: Colors.yellow,
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text("凸起按钮"),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              RaisedButton( 
                onPressed: (){
                  print("普通按钮");
                },
                child: Text("普通按钮"),
              ),
              SizedBox(width: 10,),
               RaisedButton(
                color: Colors.blue,
                textColor: Colors.white,
                onPressed: (){
                  print("有颜色的按钮");
                },
                child: Text("有颜色的按钮"),
              ),
              SizedBox(width: 10,),
              RaisedButton(
                color: Colors.blue,
                textColor: Colors.white,
                onPressed: (){
                  print("有阴影按钮");
                },
                child: Text("有阴影按钮"),
                elevation:10,  // 数值越大,阴影越大
              ),
              SizedBox(width: 10,),
              
            ],
          ),
          SizedBox(height: 10,),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              RaisedButton.icon(
                color: Colors.blue,
                textColor: Colors.white,
                onPressed: (){
                  print("图标按钮");
                },
                label: Text("图标按钮"),
                elevation:10,  // 数值越大,阴影越大
                icon: Icon(Icons.search), 
              ),
              SizedBox(width: 10,),
              RaisedButton(
                color: Colors.blue,
                textColor: Colors.white,
                onPressed: (){
                  print("圆角按钮");
                },
                child: Text("圆角按钮"),
                elevation:10, // 数值越大,阴影越大
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)   // 切圆角
                ),
              ),
              
            ],
          ),
           SizedBox(height: 10,),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Container(
                height: 80,
                child: RaisedButton(
                color: Colors.blue,
                textColor: Colors.white,
                onPressed: (){
                  print("圆形按钮");
                },
                child: Text("圆形按钮"),
                elevation:10,  // 数值越大,阴影越大
                splashColor: Colors.red,  // 点击动画效果修改
                shape:
                          CircleBorder(side: BorderSide(color: Colors.white)),  // 设置圆角,边框
              ),
              ),
              
              SizedBox(width: 10,),
              Text("扁平按钮"),
              FlatButton(
                color: Colors.blue,
                textColor: Colors.white,
                onPressed: (){
                  print("扁平按钮,没有阴影效果");
                },
                child: Text("扁平按钮"),
              // 数值越大,阴影越大
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)
                ),
              ),
            ],
          ),
          SizedBox(height: 10,),
          Text("线框按钮"),
          SizedBox(height: 10,),
          Row(
             mainAxisAlignment: MainAxisAlignment.center,
             children: <Widget>[
               // 自适应 布局
                Expanded(
                  child: Container(
                    margin: EdgeInsets.all(10),
                    height: 50,
                    //  color: Colors.red,  //没有效果
                    //  textColor: Colors.yellow,
                    child: OutlineButton(
                      child: Text("线框按钮"),
                      onPressed: (){
                        print("线框按钮");
                      },
                    ),
                  ),
                  
                )
             ],
          ),
          SizedBox(height: 10,),
          Text("按钮组"),
          SizedBox(height: 10,),
          Row(
             mainAxisAlignment: MainAxisAlignment.center,
             children: <Widget>[
               ButtonBar(
                 children: <Widget>[
                   RaisedButton(
                      child: Text('登录'),
                      color: Colors.blue,
                      textColor: Colors.white,
                      elevation: 20,
                      onPressed: () {
                        print("登录");
                      },
                    ),
                    RaisedButton(
                      child: Text('注册'),
                      color: Colors.blue,
                      textColor: Colors.white,
                      elevation: 20,
                      onPressed: () {
                        print("注册");
                      },
                    ),
                    MyButton(title: "自定义组件",width: 40,height:30,preased: (){
                      print("自定义组件");
                    },)
                    
                 ],
               )
             ],
             
          ),
         

        ],
      ),
    );
    
  }
}

class MyButton extends StatelessWidget {
  final width;
  final height;
  final preased;
  final title;
  const MyButton({this.title='',this.width=50,this.height=20,this.preased=null});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: RaisedButton(
        child: Text(this.title),
        onPressed: this.preased
      )
    );
  }
}

