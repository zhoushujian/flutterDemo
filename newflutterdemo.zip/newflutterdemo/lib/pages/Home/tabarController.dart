import 'package:flutter/material.dart';

class TabbarController extends StatefulWidget {
  TabbarController({Key key}) : super(key: key);

  _TabbarControllerState createState() => _TabbarControllerState();
}

// 继承 SingleTickerProviderStateMixin
class _TabbarControllerState extends State<TabbarController> with SingleTickerProviderStateMixin{
  TabController _tabController;

  // 这是一个生命周期函数--创建的时候
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _tabController = new TabController(
      vsync: this,length: 3
    );
    // 对tab切换进行监听
    _tabController.addListener((){
      print(_tabController.index);
    });
  }
  // 销毁时候的周期函数
  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("TabbarController"),
        bottom: TabBar(
          controller: this._tabController,
          tabs: <Widget>[
            Tab(text: "热销",),
            Tab(text: "推荐",),
            Tab(text: "洗车",)
          ],
        ),
      ),
      body: new TabBarView(
        controller: _tabController,
        children: <Widget>[
          new Center(
            child: new Text("自行车"),
          ),
          new Center(
            child: new Text("轮船"),
          ),
          new Center(
            child: new Text("巴士"),
          )
        ],
        
      ),
    );
  }
}