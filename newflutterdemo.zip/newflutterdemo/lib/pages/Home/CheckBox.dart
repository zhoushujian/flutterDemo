import 'package:flutter/material.dart';

class CheckBox extends StatefulWidget {
  CheckBox({Key key}) : super(key: key);

  _CheckBoxState createState() => _CheckBoxState();
}

class _CheckBoxState extends State<CheckBox> {
  var flag = true;
  var _groupView = 1;
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:Text("CheckBox"),
      ),
      body: Padding(
        padding: EdgeInsets.all(10),
        child: Column(
          children: <Widget>[
            Row(
              children: <Widget>[
                 Checkbox(
                   checkColor: Colors.yellow,   // 里面勾的颜色
                   activeColor: Colors.red,  // 外面的颜色
                   value: this.flag,
                   onChanged: (v){
                     setState(() {
                       this.flag = v;
                     });
                   },
                 ),
                
                  
              ],
            ),
            SizedBox(height: 40,),
              Row(
                children: <Widget>[
                  Text(this.flag? "选中":"未选中")
                ],
            ),
           
            
          ],
        ),
      ),
    );
  }
}