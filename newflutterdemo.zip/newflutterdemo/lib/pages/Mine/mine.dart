import 'package:flutter/material.dart';
import '../../res/listData.dart';

/**
 * 卡片布局 -- Card -- 用本地数据模拟网络数据,加载有图文的卡片
 */

class  Mine extends StatelessWidget{
    @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return DefaultTabController(
      length: 2,
      
      child: Scaffold(
        appBar: AppBar(
          title: Text("我的"),
          // backgroundColor: Colors.red,
          
          centerTitle: true,
          bottom: TabBar(
            indicatorColor: Colors.red,// 选中的颜色
            labelColor: Colors.black,
            tabs: <Widget>[
              Tab(text: "热门",),
              Tab(text: "推荐",),
            ],
          ),
        ),
        body: TabBarView(
          children: <Widget>[
            ListView(
              children: <Widget>[
                ListTile(
                  title: Text("第一个tab"),
                ),
                ListTile(
                  title: Text("第二个tab"),
                ),
                ListTile(
                  title: Text("第三个tab"),
                ),
                ListTile(
                  title: Text("第四个tab"),
                ),
                ListTile(
                  title: Text("第五个tab"),
                ),
                
              ],
              
            ),
            test(),
          ],
          
        ),
      ), 
      
      

    );

  }
}

class test extends StatelessWidget {
  const test({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: ListView(
      children: listData.map((value){
        return Card(
          margin: EdgeInsets.all(10),
          child: Column(
            children: <Widget>[
              AspectRatio(
                aspectRatio: 20/9,
                child: Image.network(value["imageUrl"],fit: BoxFit.cover,),
              ),
              ListTile(
                title: Text(value["title"]),
                subtitle: Text(value["author"]),
              )
            ],

          ),
        ); 
      }).toList() ,
     ),
    );
  }
}
