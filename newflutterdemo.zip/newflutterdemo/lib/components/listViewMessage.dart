import 'package:flutter/material.dart';



class CompleteListView extends StatelessWidget {
  String btn_title;
  CompleteListView({this.btn_title});
  @override
  Widget build(BuildContext context) {
    return Container(
       child: ListView(
        
       children: dataList.map((value){
          return Container(
          padding: EdgeInsets.all(10),
          
          child: Column(
            children: <Widget>[
                        Stack(
                children: <Widget>[
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Container(
                        child: Column(
                          children: <Widget>[
                            Text(value["parkingName"]),
                            Text(value["carNum"]),
                            Text(value["resvDate"])
                          ],
                        ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Container(
                      child: Column(
                        children: <Widget>[
                          Text("50.0元"),
                          
                          RaisedButton(
                            color: this.btn_title=="预约"?Colors.orange:Color.fromRGBO(213, 213, 213, 1),
                            onPressed: (){

                            },
                            child: Text('${this.btn_title}'),
                          )
                        ],
                      ),
                    )
                  ),
                  // Divider(),
                ],
              ),
              Divider(),
              
            ],
          )

          );
         },
         
       ).toList() ,
    ));
  }
}





List dataList = [
  {
    "parkingName":"创新大厦停车场",
    "carNum":"粤B123456",
    "resvDate":"08月09日",
    "payFee":"5.0元"
  },
  {
    "parkingName":"创新大厦停车场",
    "carNum":"粤B123456",
    "resvDate":"08月09日",
    "payFee":"5.0元"
  },
  {
    "parkingName":"创新大厦停车场",
    "carNum":"粤B123456",
    "resvDate":"08月09日",
    "payFee":"5.0元"
  },
  {
    "parkingName":"创新大厦停车场",
    "carNum":"粤B123456",
    "resvDate":"08月09日",
    "payFee":"5.0元"
  },
  {
    "parkingName":"创新大厦停车场",
    "carNum":"粤B123456",
    "resvDate":"08月09日",
    "payFee":"5.0元"
  },
  {
    "parkingName":"创新大厦停车场",
    "carNum":"粤B123456",
    "resvDate":"08月09日",
    "payFee":"5.0元"
  },
];


/** 
 * arNum = "\U6e58K435436";
        endTime = "2019-08-30 20:05:48";
        id = 201908301935458240000322543;
        lotNum = "B1-B\U533a-003";
        parkId = 07550000321461636544;
        parkingName = "\U6df1\U5733\U5e02\U5c55\U671b\U897f\U90e8\U7535\U5b50\U65f6\U4ee3\U5e7f\U573a\U505c\U8f66\U573a";
        payFee = 5;
        startTime = "2019-08-30 19:35:48";
        {
    carNum = "\U6e58K435436";
    lotNum = "B1-B\U533a-004";
    orderId = 201908301530371400000322850;
    parkId = 07550000321461636544;
    parkName = "\U6df1\U5733\U5e02\U5c55\U671b\U897f\U90e8\U7535\U5b50\U65f6\U4ee3\U5e7f\U573a\U505c\U8f66\U573a";
    resvDate = "2019-08-30";
    resvTime = 30;
    totalFee = 5;
}
 * 
 * 
 * */ 