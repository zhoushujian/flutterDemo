

import 'package:flutter/material.dart';

class MyDialog extends Dialog{
  String title;
  String content;

  MyDialog({this.title="",this.content=""});
  
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Material(
      
      type: MaterialType.transparency,  // 透明度
      child: Center(
        child: Container(
          height: 200,
          width: 260,
          color: Colors.white,
          child: Column(
            children: <Widget>[
              Padding(
                padding: EdgeInsets.all(10),
                child: Stack(
                  children: <Widget>[
                    Align(
                      alignment: Alignment.center,
                      child: Text(
                        "${this.title}",
                        style: TextStyle(
                        fontSize: 18,
                        // color: Colors.green,
                        fontWeight: FontWeight.bold
                      ),
                
                    ),
                    ),
      
                  ],
                ),
              ),
              Divider(),
              Container(
                padding: EdgeInsets.all(10),
                width: double.infinity,
                child: Text("${this.content}",textAlign: TextAlign.left,),
              ),
              // Divider(),
              Container(
                padding: EdgeInsets.only(top: 17),
                height: 59,
                // color: Colors.blue,
                 child: Row(
                   children: <Widget>[
                       Expanded(
                        child: Container(
                          // margin: EdgeInsets.all(10),
                          height: 50,
                          //  color: Colors.red,  //没有效果
                          //  textColor: Colors.yellow,
                          child: OutlineButton(
                            child: Text("取消"),
                            onPressed: (){
                               Navigator.pop(context);
                            },
                          ),
                       ),
                       
                  
                     ),
                     Expanded(
                        child: Container(
                          // margin: EdgeInsets.all(10),
                          height: 50,
                          //  color: Colors.red,  //没有效果
                          //  textColor: Colors.yellow,
                          child: OutlineButton(
                            child: Text("确定"),
                            onPressed: (){
                              print("确定");
                            },
                          ),
                       )
                     )
                    ],
                 ),
              ),

            ],
          ),
        ),
      ),
    );
  }
}